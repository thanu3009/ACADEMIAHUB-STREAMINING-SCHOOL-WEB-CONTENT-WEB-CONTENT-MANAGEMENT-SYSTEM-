<?php
session_start();
if(!isset($_SESSION['loggedin']) || $_SESSION['loggedin']!=true){
    header("location: login.php");
    exit;
}
?>



<?php
$user="";
$user1="";
$sl ="";
include('dbconnect.php');
$user=$_SESSION['username'];
$result = mysqli_query($conn,"SELECT s_name FROM student where s_id='".$user."' " )or die(mysqli_error());
     while($row = mysqli_fetch_array( $result ))
     {
      $user1=$row['s_name'];
     }


?>


<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.css">
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.0/jquery.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.min.js"></script>
    <title>Welcome - <?php $_SESSION['username']?></title>

  </head>
 <body>
    <?php require '_nav.php' ?>
    <div class="container my-3">
    <div class="alert alert-success" role="alert">
     <h4 class="alert-heading">Welcome - <?php echo '<b><font color="green">' . $user1 . '</font></b>';?> -  Student leave</h4>
          <br><hr>
          <form method="post" action="saveleave.php">
            <div class="mb-3">
     
            
            <div class="mb-3">
                <label>Student ID:</label>
                <input type="text" class="form-control" id="s_id" name="s_id" value="<?php echo $_SESSION['username']?>"  >
            </div>
            
           <br/>
			  <div class="mb-3">
                <label>Student Name:</label>
                <input type="text" class="form-control" id="s_name" name="s_name" value="<?php echo '' . $user1. '';?>"  >

            </div>
				  <br/>
		
<?php
 
  
   

$user2=$_SESSION['username'];

$result = mysqli_query($conn,"SELECT Stoplocation FROM student where s_id='".$user2."' " )or die(mysqli_error());
     while($row = mysqli_fetch_array( $result ))
     {
      $sl=$row['Stoplocation'];
		
     }

   
  
?>
			  <div class="mb-3">
				 
                <label>Student Location:</label>
                <input type="text" class="form-control" id="sp" name="sp" value="<?php echo '' . $sl . '';?>"  >

            </div>
           <br/>
					  <div class="mb-3">
                <label>Reason for leave:</label>
                <input type="text" class="form-control" id="res" name="res">

            </div>
           <br/>
			<div class="mb-3">
                <label>From date</label>
                <!-- <input type="text" class="form-control" id="from" name="from" placeholder="yyyy-mm-dd"> -->
                <input type="date" iclass="form-control" id="from" name="from"  min="2025-05-01" max ="2025-06-02"><br><br>

            </div>
           <br/>
					<div class="mb-3">
                <label>To date</label>
                <!-- <input type="text" class="form-control" id="to" name="to" placeholder="yyyy-mm-dd"> -->
                <input type="date" iclass="form-control" id="to" name="to"  min="2025-05-01" max ="2025-06-02"><br><br>
            </div>
           <br/>
			
          
                        <button type="Save" class="btn btn-primary">Update Leave</button>
                        <button type="reset" class="btn btn-primary">Clear</button>    
            </div>
           
     
    </form>
    </div>
    







  </div>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
  </body>
</html>
