<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "tj_schools";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_POST["submit"])) {
    $target_dir = "uploads/";
    $file_name = basename($_FILES["pdfFile"]["name"]);
    $target_file = $target_dir . $file_name;

    // Check if the file is a PDF
    $fileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
    if ($fileType != "pdf") {
        echo "Only PDF files are allowed.";
        exit;
    }

    // Move the uploaded file to the target directory
    if (move_uploaded_file($_FILES["pdfFile"]["tmp_name"], $target_file)) {
        $sql = "INSERT INTO pdf_files (file_name, file_path) VALUES ('$file_name', '$target_file')";
        if ($conn->query($sql) === TRUE) {
            echo "File uploaded successfully. <a href='view.php'>View PDFs</a>";
        } else {
            echo "Error: " . $conn->error;
        }
    } else {
        echo "Sorry, there was an error uploading your file.";
    }
}

$conn->close();
?>