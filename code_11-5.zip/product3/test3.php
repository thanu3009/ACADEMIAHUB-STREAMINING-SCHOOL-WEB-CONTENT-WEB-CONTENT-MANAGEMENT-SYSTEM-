<!DOCTYPE html>
<html>
<body>
    <form action="upload.php" method="post" enctype="multipart/form-data">
        Select PDF to upload:
        <input type="file" name="pdfFile" accept="application/pdf">
        <input type="submit" value="Upload PDF" name="submit">
    </form>
</body>
</html>
