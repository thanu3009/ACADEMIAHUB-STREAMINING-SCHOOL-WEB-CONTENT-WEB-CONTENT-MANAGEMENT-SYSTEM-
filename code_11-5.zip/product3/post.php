<?php
include('C:\xampp\htdocs\TJ2\partials\_dbconnect.php');
session_start();
$username=$_SESSION['username'];

				  

				  
				  $result = mysqli_query($conn, "SELECT * FROM `student` WHERE `username`='$username'");
				  if($row = mysqli_fetch_array( $result ))
{
	//$img = $row['p'];
}
$datetime = date("Y-m-d h:i:sa");
extract($_POST);

if($_SERVER["REQUEST_METHOD"] == "POST") {
    $message = mysqli_real_escape_string($conn,$_POST['message']);

$sql = "INSERT INTO tblpost (message, username,img) VALUES ('$message', '$username','$img')";
$fin = mysqli_query($conn, $sql);
if($fin){
$a = mysqli_query($conn, "SELECT * FROM `users` WHERE `username`='$username'");
$aa = mysqli_fetch_array($a);
if($aa){

$aaaa=$aa['username'];

$b= "INSERT INTO `tblmsg` (`username`, `message`,`img`) VALUES ('$aaaa', '$message','$img')";
$ok = mysqli_query($conn, $b);
if($ok == true) {
    echo "<script type='text/javascript'>alert(' 🤩 MESSAGE SEND Successfully !!');</script>";
    echo "<script type='text/javascript'>window.location='Discussion.php';</script>";
 }
 }
 }
}
?>