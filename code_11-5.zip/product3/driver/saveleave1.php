
<?php

   include('dbconnect.php');
   session_start();
   
   if($_SERVER["REQUEST_METHOD"] == "POST") {
     
     

      $id = mysqli_real_escape_string($conn,$_POST['s_id']);
     
      $name = mysqli_real_escape_string($conn,$_POST['s_name']);
      $res = mysqli_real_escape_string($conn,$_POST['res']);
      $fm = mysqli_real_escape_string($conn,$_POST['from']); 
      $to = mysqli_real_escape_string($conn,$_POST['to']); 
     
  
 
      
	  $sql = "INSERT INTO `drileave`(`s_id`, `s_name`,`reason`, `from`, `to`,`status`) VALUES  ('$id', '$name', '$res', '$fm', '$to','Pending')";
	  
      $result = mysqli_query($conn,$sql);
   
    echo "<script type='text/javascript'>alert(' Successfully Updated👍 !!');</script>";
    echo "<script type='text/javascript'>window.location='leaveh.php';</script>";
     
   }
?>