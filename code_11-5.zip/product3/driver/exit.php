<?php
session_start();
if(!isset($_SESSION['loggedin']) || $_SESSION['loggedin']!=true){
    header("location: login.php");
    exit;
}
?>



<?php
$user="";

include('dbconnect.php');
$user=$_SESSION['username'];
$result = mysqli_query($conn,"SELECT d_name FROM driver where d_id='".$user."' " )or die(mysqli_error());
     while($row = mysqli_fetch_array( $result ))
     {
      $user1=$row['d_name'];
     }


?>

<?php
$connection = mysqli_connect('localhost', 'root', '', 'test');

?>


<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.css">
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.0/jquery.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.min.js"></script>
    <title>Welcome - <?php echo '<b><font color="green"> ' . $user . '</font></b>';?></title>
    

    </script>
	<style>
.btn-group button {
  background-color: #04AA6D; /* Green background */
  border: 1px solid green; /* Green border */
  color: black; /* White text */
  padding: 10px 24px; /* Some padding */
  cursor: pointer; /* Pointer/hand icon */
  float: left; /* Float the buttons side by side */
}

/* Clear floats (clearfix hack) */
.btn-group:after {
  content: "";
  clear: both;
  display: table;
}

.btn-group button:not(:last-child) {
  border-right: none; /* Prevent double borders */
}

/* Add a background color on hover */
.btn-group button:hover {
  background-color: #3e8e41;
}
		.active, .btn:hover {
  background-color: #666;
  color: white;
}
</style>
  </head>
  <body>
 <?php require '_nav.php' ?>
    
    <div class="container my-3">
    <div class="alert alert-success" role="alert">
      <h4 class="alert-heading">Welcome - <?php echo '<b><font color="green">' . $user1 . '</font></b>';?></h4>
      <hr>
     
    </div>
    </br>
    <div class="banner-wthree-info container">
        <div class="row">
            <div class="col-lg-5 banner-left-info">
                
               
         
    </div>
</div>

<!-- //banner-->


		
<div class="btn-group">
  <button >ALL</button>
		<a href="stuact.php">
			<button >Entry</button></a>
	<a href="exit.php">
  <button style="background-color:yellow;">Exit</button></a>
</div>
		<p>
			
		</p>
    <table class="table table-striped table-dark">
  <thead>
    <tr>
     
     <th scope="col">  STUDENT ID</th>
      <!--  <th scope="col">  STUDENT NAME</th> -->
      <th scope="col">  BUS ID</th>
      <th scope="col">  LOCATION</th>
      <th scope="col">  BUS ENTER TIME</th>
      <!-- <th scope="col">  BUS EXIT TIME</th> -->
    </tr>
  </thead>
    <?php
     $id="";
     include('dbconnect.php');
		


    // session_start();
    //  $id=$_SESSION['username'];
    //  $result = mysqli_query($conn,"SELECT * FROM student_activity where s_id='".$id."' " )or die(mysqli_error());
		$result = mysqli_query($conn,"SELECT route FROM driver where d_id='".$user."' " )or die(mysqli_error());
     while($row = mysqli_fetch_array( $result ))
     {
$tt = $row['route'] ;
	
		
	 }

    $user1=$_SESSION['username'];
     $result = mysqli_query($conn,"SELECT * FROM exit1 where location='".$tt."' " )or die(mysqli_error());
     while($row = mysqli_fetch_array( $result ))
     {
       echo "<tr align='center'>";
       
      
       
       echo '<td><b><font color="white">' . $row['s_id'] . '</font></b></td>';
      
       // echo '<td><b><font color="white">' . $row['s_name'] . '</font></b></td>';
       echo '<td><b><font color="white">' . $row['b_id'] . '</font></b></td>';
       echo '<td><b><font color="white">' . $row['location'] . '</font></b></td>';
       echo '<td><b><font color="white">' . $row['exit_time'] . '</font></b></td>';
       // echo '<td><b><font color="white">' . $row['exit_time'] . '</font></b></td>';
   

       echo "</tr>";
                            }
                        
                            ?>        
                                                        
                                                    </tbody>
                                                    
                                                </table> 

   
   <p></p>
    
     
   



       
    <!-- js -->
 
    
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.3/dist/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
</body>
</html>