<?php
	
?>
<?php 
if(isset($_SESSION['loggedin']) && $_SESSION['loggedin']==true){
  $loggedin= true;
}
else{
  $loggedin = false;
}
?>
<html>

	<head>
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
		
	</head>
	<body>
		
		

	<?php



include('dbconnect.php');
    // session_start();
    //  $id=$_SESSION['username'];
    //  $result = mysqli_query($conn,"SELECT * FROM student_activity where s_id='".$id."' " )or die(mysqli_error());
   
     $result = mysqli_query($conn,"SELECT * FROM   schools" )or die(mysqli_error());
     while($row = mysqli_fetch_array( $result ))
     {
        $name='';

        $name =  $row['s_name'];
     }
        ?>

	<?php
echo '<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <a class="navbar-brand" >'.$name.'</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item  ">
        <a class="nav-link" href="index.php"> <i class="fa fa-home" aria-hidden="true"> Home </i> <span class="sr-only">(current)</span></a>
      </li>';

      if(!$loggedin){
      echo '<li class="nav-item">
        <a class="nav-link" href="login.php">Login</a>
      </li>
      ';
      }
      if($loggedin){
        echo '<li class="nav-item">
        <a class="nav-link" href="bus.php"><i class="fa fa-bus" aria-hidden="true"> BUS </i></a>
       </li>';
		      echo '<li class="nav-item ">
        <a class="nav-link" href="student.php"><i class="fa fa-users" aria-hidden="true"> STUDENT LIST</i></a>
       </li>';
		        echo '<li class="nav-item ">
        <a class="nav-link" href="leave.php"><i class="fa fa-book" aria-hidden="true"> STUDENT LEAVE </i></a>
       </li>';

       echo '<li class="nav-item ">
       <a class="nav-link" href="dRIleave.php"><i class="fa fa-book" aria-hidden="true"> APPLY LEAVE </i></a>
      </li>';
      echo '<li class="nav-item ">
      <a class="nav-link" href="leaveH.php"><i class="fa fa-book" aria-hidden="true">  LEAVE HISTORY </i></a>
     </li>';
  
    
    //   echo '<li class="nav-item">
    //   <a class="nav-link" href="bus.php">BUS</a>
    //  </li>';


        echo '<li class="nav-item">
        <a class="nav-link" href="../logout.php"><i class="fa fa-sign-out" aria-hidden="true"> LOGOUT</i></a>
      </li>';
    }
       
      
    echo '</ul>
  
  </div>
</nav>';
?>
			</body>
</html>