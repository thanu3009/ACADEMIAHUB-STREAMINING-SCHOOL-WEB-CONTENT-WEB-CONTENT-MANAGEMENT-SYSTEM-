DROP DATABASE testSQl;
CREATE DATABSE testSQL;
USE testSQl;

-- Create student table

CRAETE TABLE Student(
    Sl_No int auto_increment,
    Student_ID int(20) PRIMARY KEY,
    Student_Name varchar(100) NOT NULL,
    Fees float(20)NOT NULL
    );
    
    
    -- create course table
    CREATE TABLE Course(
        C_ID int(20) PRIMARY  KEY,
        C_Name varchar(100) NOT NULL,
        Student_ID int(20)
    );