
<?php
$login = false;
$showError = false;
if($_SERVER["REQUEST_METHOD"] == "POST"){
    include 'dbconnect.php';
    $username = $_POST["username"];
    $password = $_POST["password"]; 
    

      
    $result = mysqli_query($conn,"Select * from teacher where t_id='$username' and password='$password' " )or die(mysqli_error());
    while($row = mysqli_fetch_array( $result ))
    {

    // $sql = "Select * from teacher where t_id='$username' and password='$password'";
    // $result = mysqli_query($conn, $sql);
    // $num = mysqli_num_rows($result);
    // if ($num == 1){
    //     while($row=mysqli_fetch_assoc($result)){
                $login = true;
                session_start();
                $_SESSION['loggedin'] = true;
                $_SESSION['username'] = $username;
                header("location: teacher/index.php");
           
        }
        
    } 
    else{
        $showError = "Invalid Credentials";
    }


?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>Login</title>
	    <style>
	  	/*centre the display image inside the container*/
	.imgcontainer {
		text-align: center;
		margin: 24px 0 12px 0;
		position: relative;
	}

	/*set image properties*/
	img.avatar {
		width: 20%;
		border-radius: 50%;
	}
	  </style>
  </head>
  <body>
    <?php require '_nav.php' ?>
    <?php
    if($login){
    echo ' <div class="alert alert-success alert-dismissible fade show" role="alert">
        <strong>Success!</strong> You are logged in
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">×</span>
        </button>
    </div> ';
    }
    if($showError){
    echo ' <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <strong>Error!</strong> '. $showError.'
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">×</span>
        </button>
    </div> ';
    }
    ?>
 <div class="container my-3">
    <div class="alert alert-success" role="alert">
      <!-- <h4 class="alert-heading"> Hai.,Login to our website</h4> -->
          
    <div class="container my-4">
     <h1 class="text-center">Teacher Login</h1>
   
				
				<div class="imgcontainer">
				
				<img src=
"teacher\img\te.jpg" alt="Avatar" class="avatar">
			</div>
		
     <form action="tec_login.php" method="post">
        <div class="form-group">
            <label for="username"><i class="fa fa-id-card" aria-hidden="true"> Teacher UserID</i></label>
            <input type="text" class="form-control" id="username" name="username" aria-describedby="emailHelp">
            
        </div>
        <div class="form-group">
			<label for="password"><i class="fa fa-unlock-alt" aria-hidden="true"> Password</i></label>
            <input type="password" class="form-control" id="password" name="password">
        </div>
       
         
        <button type="submit" class="btn btn-primary">Login</button>
        </form><br>
        <a href="login.php">ADMIN LOGIN &nbsp;</a>
		 <a href="slogin.php"> PARENT LOGIN &nbsp;</a>
         <a href="slogin.php"> DRIVER LOGIN &nbsp;</a>
        <!-- <a href="forgot.php"><i>Forgot Password </i></a> -->
    </div>
</div>
</div>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
  </body>
</html>
