<?php
session_start();
if(!isset($_SESSION['loggedin']) || $_SESSION['loggedin']!=true){
    header("location: login.php");
    exit;
}
?>



<?php
$user="";
$user1="";
include('dbconnect.php');
$user=$_SESSION['username'];
$result = mysqli_query($conn,"SELECT s_name FROM student where s_id='".$user."' " )or die(mysqli_error());
     while($row = mysqli_fetch_array( $result ))
     {
      $user=$row['s_name'];
     }


?>

<?php  
 //$connect = mysqli_connect("localhost", "root", "", "tj_schools");  
 $result = mysqli_query($conn,"SELECT no_of_cls_attend, missed_cls FROM attednce  where s_id='".$user1."' " )or die(mysqli_error());
// $result = mysqli_query($conn, $query);  
 ?>  


<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.css">
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.0/jquery.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.min.js"></script>
    <title>Welcome - <?php echo '<b><font color="green"> ' . $user . '</font></b>';?></title>
    

    </script>

<style>
	
  .btn-group button {
    background-color: #04AA6D; /* Green background */
    border: 1px solid green; /* Green border */
    color: black; /* White text */
    padding: 5px 30px; /* Some padding */
    cursor: pointer; /* Pointer/hand icon */
     /* Float the buttons side by side */
  }
  
  /* Clear floats (clearfix hack) */
  .btn-group:after {
    content: "";
    clear: both;
    display: table;
  }
  
  .btn-group button:not(:last-child) {
    border-right: none; /* Prevent double borders */
  }
  
  /* Add a background color on hover */
  .btn-group button:hover {
    background-color: #3e8e41;
  }
      .active, .btn:hover {
    background-color: #666;
    color: white;
  }
  //end 
    
  * {box-sizing: border-box;}
  
  .mySlides {display: none;}
  img {vertical-align: middle;}
  
  /* Slideshow container */
  .slideshow-container {
    max-width: 1000px;
    position: relative;
    margin: auto;
  }
  
  /* Caption text */
  .text {
   background-color:white;
    color: black;
    font-size: 15px;
    padding: 15px 12px;
  
    bottom: -20px;
    width: 100%;
    text-align: center;
  }
  
  /* Number text (1/3 etc) */
  .numbertext {
    color: #f2f2f2;
    font-size: 12px;
    padding: 8px 12px;
    position: absolute;
    top: 0;
  }
  
  /* The dots/bullets/indicators */
  .dot {
    height: 15px;
    width: 15px;
    margin: 0 2px;
    background-color: #bbb;
    border-radius: 50%;
    display: inline-block;
    transition: background-color 0.6s ease;
  }
  
  .active {
    background-color: #717171;
  }
  
  /* Fading animation */
  .fade {
    animation-name: fade;
    animation-duration: 1.5s;
  }
  
  @keyframes fade {
    from {opacity: .4} 
    to {opacity: 1}
  }
  
  /* On smaller screens, decrease text size */
  @media only screen and (max-width: 300px) {
    .text {font-size: 11px;
    color:black;}
  }
  </style>
  </head>
  <body>
 <?php require '_nav.php' ?>
    
    <div class="container my-3">
    <div class="alert alert-success" role="alert">
      <h4 class="alert-heading">Welcome - <?php echo '<b><font color="green">' . $user . '</font></b>';?></h4>
      <hr>
    
    </div>
    </br>
    <div class="banner-wthree-info container">
        <div class="row">
            <div class="col-lg-5 banner-left-info">
                
               
         
    </div>
</div>

<!-- //banner-->


		
<div class="btn-group">
  <button >ALL</button>
		<a href="stuact.php">
			<button >Homework</button></a>
	<!-- <a href="exam.php">
  <button >Exam - Test</button></a> -->
  <a href="mark.php">
  <button>Marks card</button></a>
  <a href="att.php">
  <button style="background-color:yellow;">ATTENDNANCE REPORTS</button></a>

</div>
		<p>
			
		</p>
    <table class="table table-striped table-dark">
  <thead>
    <tr>
     
      <!-- <th scope="col">  STUDENT ID</th>
      <th scope="col">  STUDENT NAME</th> -->
      <th scope="col">  SCHOOL ATTENDNANCE YEAR</th>
      <th scope="col">  NO OF CLASSES</th>
      <th scope="col"> NO OF CLASSES ATTENDED</th>
      <th scope="col"> MISSED CLASSES </th>
      <!-- <th scope="col">  BUS EXIT TIME</th> -->
    </tr>
  </thead>
    <?php
     $id="";
     include('dbconnect.php');
		


    // session_start();
    //  $id=$_SESSION['username'];
    //  $result = mysqli_query($conn,"SELECT * FROM student_activity where s_id='".$id."' " )or die(mysqli_error());
    $user1=$_SESSION['username'];
     $result = mysqli_query($conn,"SELECT * FROM attednce where s_id='".$user1."' " )or die(mysqli_error());
     while($row = mysqli_fetch_array( $result ))
     {
       echo "<tr align='center'>";
       
      
       
       // echo '<td><b><font color="white">' . $row['s_id'] . '</font></b></td>';
      
       // echo '<td><b><font color="white">' . $row['s_name'] . '</font></b></td>';
       echo '<td><b><font color="white">' . $row['class_year'] . '</font></b></td>';
       echo '<td><b><font color="white">' . $row['no_of_cls_taken'] . '</font></b></td>';
       echo '<td><b><font color="white">' . $row['no_of_cls_attend'] . '</font></b></td>';
       echo '<td><b><font color="white">' . $row['missed_cls'] . '</font></b></td>';
       // echo '<td><b><font color="white">' . $row['exit_time'] . '</font></b></td>';
   

       echo "</tr>";
                            }
                        
                            ?>        
                                                        
                                                    </tbody>
                                                    
                                                </table> 

   
   <p></p>
    
     
   



       
    <!-- js -->
    <script>
let slideIndex = 0;
showSlides();

function showSlides() {
  let i;
  let slides = document.getElementsByClassName("mySlides");
  let dots = document.getElementsByClassName("dot");
  for (i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";  
  }
  slideIndex++;
  if (slideIndex > slides.length) {slideIndex = 1}    
  for (i = 0; i < dots.length; i++) {
    dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";  
  dots[slideIndex-1].className += " active";
  setTimeout(showSlides, 1000); // Change image every 5 seconds
}
</script>


<br /><br />  
           <div style="width:900px;">  
                <h3 align="center">Students Attendance Visualization</h3>  
                <br />  
                <div id="piechart" style="width: 900px; height: 500px;"></div>  
           </div>  

    
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.3/dist/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
</body>
</html>