<?php
  include('dbconnect.php');
   session_start();
   
     if($_SERVER["REQUEST_METHOD"] == "GET") {
	  
	  $id = mysqli_real_escape_string($conn,$_GET['id']); 
	  
	  $sql = "DELETE FROM studentleav  where le_id='$id'";	  
	  echo $sql;
      $result = mysqli_query($conn,$sql);
	  
	
	echo "<script type='text/javascript'>alert('Leave Record has been Deleted');</script>";
	echo "<script type='text/javascript'>window.location='Leavemain.php';</script>";
	 }
	

   //}
?>