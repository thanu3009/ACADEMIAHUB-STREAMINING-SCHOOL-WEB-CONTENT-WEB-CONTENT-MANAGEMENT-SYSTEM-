<?php
session_start();
if(!isset($_SESSION['loggedin']) || $_SESSION['loggedin']!=true){
    header("location: login.php");
    exit;
}
?>



<?php
$user="";

include('dbconnect.php');
$user=$_SESSION['username'];
$result = mysqli_query($conn,"SELECT s_name FROM student where s_id='".$user."' " )or die(mysqli_error());
     while($row = mysqli_fetch_array( $result ))
     {
      $user=$row['s_name'];
     }


?>

<?php
$connection = mysqli_connect('localhost', 'root', '', 'test');

?>

<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.css">
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.0/jquery.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.min.js"></script>
    <title>Welcome - <?php $_SESSION['username']?></title>
	</head>
	<body>
		
		 <body>
    <?php require '_nav.php' ?>
    
    <div class="container my-3">
    <div class="alert alert-success" role="alert">
    <h4 class="alert-heading">Welcome - <?php echo '<b><font color="green">' . $user . '</font></b>';?></h4>
      <hr>
      <p class="mb-0">Whenever you need to, be sure to logout <a href="logout.php"> using this link.</a></p>
    </div>
    <br/>
			  <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3928.511021769398!2d76.3584952143131!3d10.05714809281199!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3b080d852df13da7%3A0x9dcfa7655f5fb5eb!2sTCS%20TECH%20PARK!5e0!3m2!1sen!2sin!4v1667149963474!5m2!1sen!2sin" width="100%" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
			 </div>
	</body>
</html>