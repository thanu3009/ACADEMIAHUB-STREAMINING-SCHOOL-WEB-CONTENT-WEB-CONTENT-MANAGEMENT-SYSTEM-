<?php
session_start();
if(!isset($_SESSION['loggedin']) || $_SESSION['loggedin']!=true){
    header("location: login.php");
    exit;
}
?>




<?php
$user="";
$user1="";

include('dbconnect.php');
$user=$_SESSION['username'];
$result = mysqli_query($conn,"SELECT t_name FROM teacher where t_id='".$user."' " )or die(mysqli_error());
     while($row = mysqli_fetch_array( $result ))
     {
      $user1=$row['t_name'];
     }


?>


<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.css">
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.0/jquery.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.min.js"></script>
    <title>Welcome - <?php $_SESSION['username']?></title>
<style>

  
.button-container {
            display: flex;
            gap: 20px;
        }

        .button {
            padding: 10px 20px;
            font-size: 16px;
            font-weight: bold;
            color: white;
            text-transform: uppercase;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2);
            transition: transform 0.2s, box-shadow 0.2s;
        }

        .button:hover {
            transform: scale(1.1);
            box-shadow: 0 6px 8px rgba(0, 0, 0, 0.3);
        }

        .btn-primary {
            background-color: #4CAF50;
        }

        .btn-secondary {
            background-color: #2196F3;
        }

        .btn-danger {
            background-color: #f44336;
        }
      
  </style>
  </head>
 <body>
    <?php require 'teacher/_nav.php' ?>
    <div class="container my-3">
    <div class="button-container">
    <a href="tNotes.php" class="button btn-secondary">ADD NEW Notes</a>
        <a href="tviewnotes.php" class="button btn-primary">VIEW Notes</a>
        
        <!-- <a href="driverleave.php" class="button btn-danger">DRIVERS LEAVE</a> -->
    </div>
<br/>

    <div class="alert alert-success" role="alert">
     <h4 class="alert-heading">Welcome - <?php echo '<b><font color="green">' . $user1 . '</font></b>';?> -  Add Class Notes</h4>
          <br><hr>
          <form action="tupload.php" method="post" enctype="multipart/form-data">
            <div class="mb-3">
     
            
            <div class="mb-3">
                <label>Teacher ID:</label>
                <input type="text" class="form-control" id="t_id" name="t_id" value="<?php echo $_SESSION['username']?>"  >
            </div>
            
           <br/>
			  <div class="mb-3">
                <label>Class Name:</label>

                    <select name="cls">
                    <option value="c101">LKG</option>
                    <option value="c102">UKG</option>
                   <option value="c103">1st Class</option>
                   <option value="c104">2nd Class</option>
                   <option value="c105">3rd Class</option>
                   <option value="c106">4th Class</option>
                   <option value="c107">5th Class</option>
                   <!-- <option value="c108">Sports</option> -->
                   
            </div>
			
		</select>
    <br/>  
    <br/>
			  <div class="mb-3">

          <?php
          $sub ='';
          $id='';
  

      $result = mysqli_query($conn,"SELECT * FROM tec_sub where t_id='".$user."' " )or die(mysqli_error());
     while($row = mysqli_fetch_array( $result ))
     {
      $sub=$row['sub_name'];
      $id=$row['sub_id'];
		
		
     }

   #echo $sub;
  
?>
                <label>Subject Name: </label>
                <input type="text" class="form-control" id="sname" name="sname" value="<?php echo '' . $sub . '';?>"  >
    </br>
                <label>Subject ID: </label>
                <input type="text" class="form-control" id="sid" name="sid" value="<?php echo '' . $id . '';?>"  >

            </div>
           <br/>
			

<!-- <form action="upload.php" method="post" enctype="multipart/form-data"> -->
    <label>Select PDF to upload: </label>
        <!-- Select PDF to upload: -->
        <input type="file" id ="pdfFile" name="pdfFile" accept="application/pdf">

			    <br/>
            <br/>
                       <input type="submit" value="Upload PDF" name="submit">
                        <button type="reset" class="btn btn-primary">Clear</button>    
            </div>
           
     
    </form>
    </div>
    







  </div>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
  </body>
</html>
