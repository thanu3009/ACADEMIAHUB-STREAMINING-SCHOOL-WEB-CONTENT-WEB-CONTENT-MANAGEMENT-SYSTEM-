<?php

   include('dbconnect.php');
   session_start();

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
   $uid= $_POST['uid'];
    $comments = $_POST['comments'];

    $sql = "INSERT INTO feedback (name, uid,comments) VALUES ('$name','$uid', '$comments')";
    if ($conn->query($sql)) {
       
        echo "<script type='text/javascript'>alert(' Feedback sent Successfully !!');</script>";
        echo "<script type='text/javascript'>window.location='chat.php';</script>";
    } else {
        echo "Error: " . $conn->error;
    }
}

$conn->close();
?>