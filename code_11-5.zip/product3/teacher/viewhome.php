<?php
session_start();
if(!isset($_SESSION['loggedin']) || $_SESSION['loggedin']!=true){
    header("location: login.php");
    exit;
}
?>




<?php
$user="";
$user1="";

include('dbconnect.php');
$user=$_SESSION['username'];
$result = mysqli_query($conn,"SELECT t_name FROM teacher where t_id='".$user."' " )or die(mysqli_error());
     while($row = mysqli_fetch_array( $result ))
     {
      $user1=$row['t_name'];
     }


?>


<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.css">
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.0/jquery.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.min.js"></script>
    <title>Welcome - <?php $_SESSION['username']?></title>
<style>

  
.button-container {
            display: flex;
            gap: 20px;
        }

        .button {
            padding: 10px 20px;
            font-size: 16px;
            font-weight: bold;
            color: white;
            text-transform: uppercase;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2);
            transition: transform 0.2s, box-shadow 0.2s;
        }

        .button:hover {
            transform: scale(1.1);
            box-shadow: 0 6px 8px rgba(0, 0, 0, 0.3);
        }

        .btn-primary {
            background-color: #4CAF50;
        }

        .btn-secondary {
            background-color: #2196F3;
        }

        .btn-danger {
            background-color: #f44336;
        }
      
  </style>
  </head>
 <body>
    <?php require '_nav.php' ?>
    <div class="container my-3">
    <div class="button-container">
    <a href="stuact.php" class="button btn-secondary">ADD NEW HOMEWORK</a>
        <a href="viewhome.php" class="button btn-primary">VIEW OLD HOMEWORK</a>
        
        <!-- <a href="driverleave.php" class="button btn-danger">DRIVERS LEAVE</a> -->
    </div>
<br/>

<table class="table table-striped table-dark" class="table table-bordered" >
  <thead>
    <tr bgcolor="rgb(111, 111, 111)">
     
      <!-- <th scope="col">  STUDENT ID</th> -->
      <th scope="col">  Class NAME</th>
      <th scope="col"> Subject</th>
      <th scope="col"> Topic</th>
      <th scope="col"> Due date</th>
      <th scope="col"> Status</th>
      <!-- <th scope="col">  BUS EXIT TIME</th> -->
    </tr>
  </thead>
    <?php
     $id="";
     include('dbconnect.php');
		


    // session_start();
    //  $id=$_SESSION['username'];
    //  $result = mysqli_query($conn,"SELECT * FROM student_activity where s_id='".$id."' " )or die(mysqli_error());
    $user1=$_SESSION['username'];
     $result = mysqli_query($conn,"SELECT * FROM homework1 where t_id='".$user1."' " )or die(mysqli_error());
     while($row = mysqli_fetch_array( $result ))
     {
       echo "<tr align='center'>";
       
      
       
       // echo '<td><b><font color="white">' . $row['s_id'] . '</font></b></td>';
      
       echo '<td><b><font color="white">' . $row['cls_name'] . '</font></b></td>';
       echo '<td><b><font color="white">'.$row['subject'] . '</font></b></td>';
       echo '<td><b><font color="white">'.$row['topic'] . '</font></b></td>';
       echo '<td><b><font color="white">'.$row['due_date'] . '</font></b></td>';
       echo '<td><b><font color="white">' . $row['status'] . '</font></b></td>';
       echo'<td> <a href="delete.php?id=' . $row['h_id'] . '" ><button type="Submit" style="background-color:red; color:white;">Delete</button></a></td>';

   

       echo "</tr>";
                            }
                        
                            ?>        
                                                        
                                                    </tbody>
                                                    
                                                </table> 

   
   <p></p>
    
     
   



       
    <!-- js -->
 
    
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.3/dist/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
</body>
</html>