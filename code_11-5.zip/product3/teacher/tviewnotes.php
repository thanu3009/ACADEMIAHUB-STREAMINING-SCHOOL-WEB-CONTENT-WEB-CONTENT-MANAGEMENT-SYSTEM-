<?php
session_start();
if(!isset($_SESSION['loggedin']) || $_SESSION['loggedin']!=true){
    header("location: login.php");
    exit;
}
?>




<?php
$user="";
$user1="";

include('dbconnect.php');
$user=$_SESSION['username'];
$result = mysqli_query($conn,"SELECT t_name FROM teacher where t_id='".$user."' " )or die(mysqli_error());
     while($row = mysqli_fetch_array( $result ))
     {
      $user1=$row['t_name'];
     }


?>


<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.css">
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.0/jquery.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.min.js"></script>
    <title>Welcome - <?php $_SESSION['username']?></title>
<style>

  
.button-container {
            display: flex;
            gap: 20px;
        }

        .button {
            padding: 10px 20px;
            font-size: 16px;
            font-weight: bold;
            color: white;
            text-transform: uppercase;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2);
            transition: transform 0.2s, box-shadow 0.2s;
        }

        .button:hover {
            transform: scale(1.1);
            box-shadow: 0 6px 8px rgba(0, 0, 0, 0.3);
        }

        .btn-primary {
            background-color: #4CAF50;
        }

        .btn-secondary {
            background-color: #2196F3;
        }

        .btn-danger {
            background-color: #f44336;
        }
      
  </style>
  </head>
 <body>
    <?php require '_nav.php' ?>
    <div class="container my-3">
    <div class="button-container">
    <a href="tNotes.php" class="button btn-secondary">ADD NEW Notes</a>
        <a href="tviewnotes.php" class="button btn-primary">VIEW Notes</a>
        
        <!-- <a href="driverleave.php" class="button btn-danger">DRIVERS LEAVE</a> -->
    </div>
<br/>

 <table class="table table-striped table-dark">
  <thead>
    <tr>
     
      <th scope="col">  Class Name</th>
      <th scope="col">  Subject</th> 
      <!-- <th scope="col">   Location</th> -->
      <th scope="col">  Notes</th>
      <th scope="col"> DATE</th>
      
    </tr>
  </thead>
    <?php
     $id="";
     include('dbconnect.php');
		


    		

 
     $result = mysqli_query($conn,"SELECT * FROM pdf_files" )or die(mysqli_error());
     while($row = mysqli_fetch_array( $result ))
     {
       echo "<tr align='center'>";
       
      
       
       echo '<td><b><font color="white">' . $row['cls_name'] . '</font></b></td>';
      
       echo '<td><b><font color="white">' . $row['subject'] . '</font></b></td>';
   //echo '<td><b><font color="white">' . $row['file_path'] . '</font></b></td>';
 //echo "<a href='" . $row["file_path"] . "' target='_blank'>" . $row["file_name"] . "</a><br>";

       echo "<td <b><font color='white'><a href='" . $row["file_path"] . "' target='_blank'>" . $row["file_name"] . "</a></font></b></td>";

       echo '<td><b><font color="white">' . $row['uploaded_at'] . '</font></b></td>';
       echo'<td> <a href="tdeletenotes.php?id=' . $row['id'] . '" ><button type="Submit" style="background-color:red; color:white;">Delete</button></a></td>';

      
   

       echo "</tr>";
                            }
                        
                            ?>        
                                                        
                                                    </tbody>
                                                    
                                                </table> 
   <!-- <?php
// $servername = "localhost";
// $username = "root";
// $password = "";
// $dbname = "tj_schools";

// $conn = new mysqli($servername, $username, $password, $dbname);

// if ($conn->connect_error) {
//     die("Connection failed: " . $conn->connect_error);
// }

// $sql = "SELECT * FROM pdf_files";
// $result = $conn->query($sql);

// if ($result->num_rows > 0) {
//     while ($row = $result->fetch_assoc()) {
//         echo "<a href='" . $row["file_path"] . "' target='_blank'>" . $row["file_name"] . "</a><br>";
//     }
// } else {
//     echo "No PDFs uploaded.";
// }

// $conn->close();
?> -->




  </div>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
  </body>
</html>
