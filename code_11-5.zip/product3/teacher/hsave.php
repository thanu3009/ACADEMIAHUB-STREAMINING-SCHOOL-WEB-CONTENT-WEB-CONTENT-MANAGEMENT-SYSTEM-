<?php
	
?>
<?php

   include('dbconnect.php');
   session_start();
   
   if($_SERVER["REQUEST_METHOD"] == "POST") {
     
     

      $tid = mysqli_real_escape_string($conn,$_POST['t_id']);
      $cls = mysqli_real_escape_string($conn,$_POST['cls']);
	  $sname = mysqli_real_escape_string($conn,$_POST['sname']);
      $sid = mysqli_real_escape_string($conn,$_POST['sid']);
      $top = mysqli_real_escape_string($conn,$_POST['top']);
      $to = mysqli_real_escape_string($conn,$_POST['to']); 
     
  
   
  
      
     
      $clsname='';
      $result = mysqli_query($conn,"SELECT c_name FROM cls where c_id='".$cls."' " )or die(mysqli_error());
           while($row = mysqli_fetch_array( $result ))
           {
            $clsname=$row['c_name'];
           }
      
      
     
      
	  $sql = "INSERT INTO `homework1`(`t_id`,`cls_id`,`cls_name`,`sub_id`,`subject`, `topic`, `due_date`)
       VALUES  ('$tid', '$cls', '$clsname','$sid', '$sname', '$top', '$to')";
	  
      $result = mysqli_query($conn,$sql);
   
    echo "<script type='text/javascript'>alert(' Successfully Homework Updated👍 !!');</script>";
        echo "<script type='text/javascript'>window.location='stuact.php';</script>";
     
   }
?>
