<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "tj_schools";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM pdf_files";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<a href='" . $row["file_path"] . "' target='_blank'>" . $row["file_name"] . "</a><br>";
    }
} else {
    echo "No PDFs uploaded.";
}

$conn->close();
?>
