<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "tj_schools";
$conn = new mysqli($servername, $username, $password, $dbname);

//echo "hi";

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
if (isset($_POST["submit"])) {
     
     
    $target_dir = "uploads/";
    $file_name = basename($_FILES["pdfFile"]["name"]);
    $target_file = $target_dir . $file_name;
    
    // $tid = mysqli_real_escape_string($conn,$_POST['t_id']);
    // $cls = mysqli_real_escape_string($conn,$_POST['cls']);
	// $sname = mysqli_real_escape_string($conn,$_POST['sname']);
    // $sid = mysqli_real_escape_string($conn,$_POST['sid']);

    // Check if the file is a PDF
    $fileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
    if ($fileType != "pdf") {
        echo "Only PDF files are allowed.";
        exit;
    }

    //  $clsname='';
    //   $result = mysqli_query($conn,"SELECT c_name FROM cls where c_id='".$cls."' " )or die(mysqli_error());
    //        while($row = mysqli_fetch_array( $result ))
    //        {
    //         $clsname=$row['c_name'];
    //        }

    // Move the uploaded file to the target directory
    if (move_uploaded_file($_FILES["pdfFile"]["tmp_name"], $target_file)) {
        $sql = "INSERT INTO pdf_files (	t_id, cls_name,sub_id, subject,file_name, file_path) VALUES ('$tid','$clsname','$sid','$sname', '$file_name', '$target_file')";
        if ($conn->query($sql) === TRUE) {
            echo "File uploaded successfully. <a href='view.php'>View PDFs</a>";
        } else {
            echo "Error: " . $conn->error;
        }
    } else {
        echo "Sorry, there was an error uploading your file.";
    }
}

$conn->close();
?>