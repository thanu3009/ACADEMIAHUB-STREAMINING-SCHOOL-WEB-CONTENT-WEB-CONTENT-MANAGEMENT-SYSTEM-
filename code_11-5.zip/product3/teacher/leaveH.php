<?php
session_start();
if(!isset($_SESSION['loggedin']) || $_SESSION['loggedin']!=true){
    header("location: login.php");
    exit;
}
?>



<?php
$user="";

include('dbconnect.php');
$user=$_SESSION['username'];
$result = mysqli_query($conn,"SELECT t_name FROM teacher where t_id='".$user."' " )or die(mysqli_error());
     while($row = mysqli_fetch_array( $result ))
     {
      $user=$row['t_name'];
     }


?>




<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.css">
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.0/jquery.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.min.js"></script>
    <title>Welcome - </title>
    

    </script>
  </head>
  <body>
    <?php require '_nav.php' ?>
    <div class="container my-3">
    <div class="alert alert-success" role="alert">
      <h4 class="alert-heading">Welcome - <?php echo '<b><font color="green">' . $user . '</font></b>';?></h4>
      <hr>
    
    </div>
    </br>
    <div class="banner-wthree-info container">
        <div class="row">
            <div class="col-lg-5 banner-left-info">
                
               
         
 </div>
<!-- //banner-->
<div class="">
      <P></P>
     
   
    </div>
    <p></p>
    <table class="table table-striped table-dark">
  <thead>
    <tr>
     
     
      <th scope="col">  TEACHER NAME</th>
      <th scope="col">  REASON FOR LEAVE</th>
      <th scope="col">  FROM DATE</th>
      <th scope="col">  TO DATE</th>
      <th scope="col">  STATUS</th>

      
    </tr>
  </thead>
    <?php
     $id="";
     include('dbconnect.php');
		


    
    $user1=$_SESSION['username'];
     $result = mysqli_query($conn,"SELECT * FROM techleave where s_id='".$user1."' " )or die(mysqli_error());
     while($row = mysqli_fetch_array( $result ))
     {
       echo "<tr align='center'>";
       
      
       
       // echo '<td><b><font color="white">' . $row['s_id'] . '</font></b></td>';
      
       echo '<td><b><font color="white">' . $row['s_name'] . '</font></b></td>';
       echo '<td><b><font color="white">' . $row['reason'] . '</font></b></td>';
       echo '<td><b><font color="white">' . $row['from'] . '</font></b></td>';
       echo '<td><b><font color="white">' . $row['to'] . '</font></b></td>';
       echo '<td><b><font color="white">' . $row['status'] . '</font></b></td>';
       echo'<td> <a href="deleteleave.php?id=' . $row['le_id'] . '" ><button type="Submit" style="background-color:red; color:white;">Delete</button></a></td>';
      
   

       echo "</tr>";
                            }
                        
                            ?>        
                                                        
                                                    </tbody>
                                                    
                                                </table> 

   
   <p></p>
    
     
   
   
</div>



       
    <!-- js -->
 
    
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.3/dist/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
</body>
</html>