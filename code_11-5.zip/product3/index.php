<?php
session_start();
if(!isset($_SESSION['loggedin']) || $_SESSION['loggedin']!=true){
    header("location: login.php");
    exit;
}
?>



<?php
$user="";
$user1="";

include('dbconnect.php');
$user=$_SESSION['username'];
$user=$_SESSION['username'];
$user1=$_SESSION['username'];
$result = mysqli_query($conn,"SELECT s_name FROM student where s_id='".$user."' " )or die(mysqli_error());
     while($row = mysqli_fetch_array( $result ))
     {
      $user=$row['s_name'];
     }


?>


<?php  
 //$connect = mysqli_connect("localhost", "root", "", "tj_schools");  
 $result = mysqli_query($conn,"SELECT no_of_cls_attend, missed_cls FROM attednce  where s_id='".$user1."' " )or die(mysqli_error());
// $result = mysqli_query($conn, $query);  
 ?>  
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.css">
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.0/jquery.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.min.js"></script>
	  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>Welcome - <?php $_SESSION['username']?></title>

  <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>  
           <script type="text/javascript">  
           google.charts.load('current', {'packages':['corechart']});  
           google.charts.setOnLoadCallback(drawChart);  
           function drawChart()  
           {  
                var data = google.visualization.arrayToDataTable([  
                          ['No_of_cls_attend', 'missed_cls'],  
                          <?php  
                          while($row = mysqli_fetch_array($result))  
                          {  
                               echo "['".$row["no_of_cls_attend"]."', ".$row["missed_cls"]."],";  
                          }  
                          ?>  
                     ]);  
                var options = {  
                      title: 'Students Attendance Visualization',  
                      //is3D:true,  
                      pieHole: 0.4  
                     };  
                var chart = new google.visualization.PieChart(document.getElementById('piechart'));  
                chart.draw(data, options);  
           }  
           </script>  

<style>
	
.btn-group button {
  background-color: #04AA6D; /* Green background */
  border: 1px solid green; /* Green border */
  color: black; /* White text */
  padding: 5px 30px; /* Some padding */
  cursor: pointer; /* Pointer/hand icon */
   /* Float the buttons side by side */
}

/* Clear floats (clearfix hack) */
.btn-group:after {
  content: "";
  clear: both;
  display: table;
}

.btn-group button:not(:last-child) {
  border-right: none; /* Prevent double borders */
}

/* Add a background color on hover */
.btn-group button:hover {
  background-color: #3e8e41;
}
		.active, .btn:hover {
  background-color: #666;
  color: white;
}
//end 
	
* {box-sizing: border-box;}

.mySlides {display: none;}
img {vertical-align: middle;}

/* Slideshow container */
.slideshow-container {
  max-width: 1000px;
  position: relative;
  margin: auto;
}

/* Caption text */
.text {
 background-color:white;
  color: black;
  font-size: 15px;
  padding: 15px 12px;

  bottom: -20px;
  width: 100%;
  text-align: center;
}

/* Number text (1/3 etc) */
.numbertext {
  color: #f2f2f2;
  font-size: 12px;
  padding: 8px 12px;
  position: absolute;
  top: 0;
}

/* The dots/bullets/indicators */
.dot {
  height: 15px;
  width: 15px;
  margin: 0 2px;
  background-color: #bbb;
  border-radius: 50%;
  display: inline-block;
  transition: background-color 0.6s ease;
}

.active {
  background-color: #717171;
}

/* Fading animation */
.fade {
  animation-name: fade;
  animation-duration: 1.5s;
}

@keyframes fade {
  from {opacity: .4} 
  to {opacity: 1}
}

/* On smaller screens, decrease text size */
@media only screen and (max-width: 300px) {
  .text {font-size: 11px;
	color:black;}
}
</style>
  </head>
  <body>

 
    <?php require '_nav.php' ?>
    
    <div class="container my-3">
    <div class="alert alert-success" role="alert">
    <h4 class="alert-heading">Welcome - <?php echo '<b><font color="green">' . $user . '</font></b>';?> </h4>
      <hr>
    
    </div>
    <br/>
  <!--/banner-->
  <div class="banner-wthree-info container">
        <div class="row">
            <div class="col-lg-5 banner-left-info">
                
               
         
    </div>
</div>

<!-- //banner-->
<div class="">
     		
<div class="btn-group">
  
		<a href="studentlocation.php">
			<button ><i class="fa fa-map-marker" aria-hidden="true"> STUDENT LOCATION</i></button></a>
	<a href="buslocation.php">
		<button><i class="fa fa-map-marker" aria-hidden="true"> BUS LOCATION</i></button></a>
</div>
     
   
    </div>
    <p></p>
	     
<div class="slideshow-container">

<div class="mySlides fade">
  <div class="numbertext">1 / 6</div>
  <img src="img\1.jpg" style="width:100%">
  <div class="text">Being a School Bus Driver Is Not Just A Job… It’s an Adventure!</div>
</div>

<div class="mySlides fade">
  <div class="numbertext">2 / 6</div>
  <img src="img/2.png" style="width:100%">
  <div class="text">Anyone Can Drive A Car But It Takes Someone Special to Drive a School Bus!</div>
</div>

<div class="mySlides fade">
  <div class="numbertext">3 / 6</div>
  <img src="img/3.png" style="width:100%">
  <div class="text">Be Nice To The School Bus Driver, It’s A Long Walk From Home To School!</div>
</div>

<div class="mySlides fade">
  <div class="numbertext">4 / 6</div>
  <img src="img\ch1.jpg" style="width:100%">
  <div class="text">Being a School Bus Driver Is Not Just A Job… It’s an Adventure!</div>
</div>

<div class="mySlides fade">
  <div class="numbertext">5 / 6</div>
  <img src="img/ch2.jpg" style="width:100%">
  <div class="text">Anyone Can Drive A Car But It Takes Someone Special to Drive a School Bus!</div>
</div>

<div class="mySlides fade">
  <div class="numbertext">6 / 6</div>
  <img src="img/ch3.jpg" style="width:100%">
  <div class="text">Be Nice To The School Bus Driver, It’s A Long Walk From Home To School!</div>
</div>

</div>
<br>

<div style="text-align:center">
  <span class="dot"></span> 
  <span class="dot"></span> 
  <span class="dot"></span> 
  <span class="dot"></span> 
  <span class="dot"></span> 
  <span class="dot"></span>   
</div>

    
    <?php
     
                            ?>        
                                                        
                                                
    
     
   



       
    <!-- js -->
    <script>
let slideIndex = 0;
showSlides();

function showSlides() {
  let i;
  let slides = document.getElementsByClassName("mySlides");
  let dots = document.getElementsByClassName("dot");
  for (i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";  
  }
  slideIndex++;
  if (slideIndex > slides.length) {slideIndex = 1}    
  for (i = 0; i < dots.length; i++) {
    dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";  
  dots[slideIndex-1].className += " active";
  setTimeout(showSlides, 1000); // Change image every 5 seconds
}
</script>


<br /><br />  
           <!-- <div style="width:900px;">  
                <h3 align="center">Students Attendance Visualization</h3>  
                <br />  
                <div id="piechart" style="width: 900px; height: 500px;"></div>  
           </div>   -->

    
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.3/dist/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
</body>
</html>