drop database TJ_Schools;
CREATE DATABASE TJ_Schools;
USE TJ_Schools;


CREATE TABLE `sub` (
  `sub_id` varchar(20) NOT NULL,
  `sub_name` varchar(100) NOT NULL  
); 

ALTER TABLE `sub` ADD PRIMARY KEY (`sub_id`);

INSERT INTO `sub` (`sub_id`, `sub_name`)  VALUES
('S101', 'Kannada'),('S102', 'English'),
('S103', 'Maths'),('S104', 'Science'),
('S105', 'Hindi'),('S106', 'Scocial-Science'),
('S107', 'Sports');


CREATE TABLE `tech` (
  `t_id` int(20) NOT NULL,
  `t_name` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
); 

ALTER TABLE `tech` ADD PRIMARY KEY (`t_id`);

INSERT INTO `tech` (`t_id`, `t_name`,`password`)  VALUES
(555, 'Ram-Prasad','ramu'),
(666, 'Raghu-Ram', 'ragu'),
(777, 'Bheeshma', 'bhee'),
(888, 'Ravichnadra', 'ravi'),
(999, 'Suma', 'suma'),
(101, 'Apsara', 'apsa');



CREATE TABLE `cls` (
  `c_id` varchar(20) NOT NULL,
  `c_name` varchar(100) NOT NULL
    
); 


ALTER TABLE `cls` ADD PRIMARY KEY (`c_id`);

INSERT INTO `cls` (`c_id`, `c_name`)  VALUES

('c101', 'LKG'),('c102', 'UKG'),
('c103', '1st class'),('c104', '2nd class'),
('c105', '3rd class'),('c106', '4th class'),
('c107', '5th class'),('c108', 'sports');




CREATE TABLE `tec_sub` (
  `t_id` int(20) NOT NULL,
  `sub_id` varchar(20) NOT NULL,
  `sub_name` varchar(50) NOT NULL
); 

ALTER TABLE `tec_sub` ADD FOREIGN KEY (`sub_id`) REFERENCES `sub`(`sub_id`);

INSERT INTO `tec_sub` (`t_id`, `sub_id`, `sub_name`)  VALUES
(555, 'S101','Kannada'),(555, 'S106','Scocial-Science'),
(666, 'S102','English'),(666, 'S104','Science'),
(777, 'S103','Maths'),(888, 'S107','Science'),(999, 'S105','Hindi');



CREATE TABLE `student` (
  `s_id` int(20) NOT NULL,
  `s_name` varchar(100) NOT NULL,
  `Stoplocation` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `class` varchar(100) NOT NULL,
  `c_id` varchar(20) NOT NULL
    
); 

ALTER TABLE `student`ADD PRIMARY KEY (`s_id`);
ALTER TABLE `student` ADD FOREIGN KEY (`c_id`) REFERENCES `cls`(`c_id`);



INSERT INTO `student` (`s_id`, `s_name`, `Stoplocation`,`address`,`password`,`class`, `c_id`)  VALUES
(1001, 'Mahananda', 'GUN-HOUSE','#601, Near temple, MYSORE','maha','1ST-CLASS','c103'),
(1002, 'Siddhant', 'RMC','#701, Near HP BANK, MYSORE','sidd','LKG','c101'),
(1003, 'Navin', 'YALE-THOTA','#801, Near JSS COLLEGE , MYSORE','navi','UKG','c102'),
(1004, 'Teja', 'GUN-HOUSE','#201, Near temple, MYSORE','teja','1ST-CLASS','c103'),
(1005, 'Basava', 'RMC','#101, Near HP BANK, MYSORE','basa','2ND-CLASS','c104'),
(1006, 'Manu', 'YALE-THOTA','#901, Near JSS COLLEGE , MYSORE','manu','2ND-CLASS','c104');


CREATE TABLE `function` (
  `f_id` int(20) NOT NULL,
  `fun_name` varchar(100) NOT NULL,
  `fun_locatin` varchar(100) NOT NULL,
    `fun_date` varchar(100) NOT NULL
); 
ALTER TABLE `function` ADD PRIMARY KEY (`f_id`);

INSERT INTO `function` (`f_id`, `fun_name`,`fun_locatin`,`fun_date`) VALUES
(123,'25th Anniversary','TJ_School Ground','2025-04-10'),
(124,'Independence-Day','TJ_School Ground','2025-08-15'),
(125,'Telent-Day','TJ_School ','2025-08-30');


CREATE TABLE `fee` (
  `f_id` int(20) NOT NULL,
    `class` varchar(50) NOT null,
  `fee` varchar(100) NOT NULL,
    `add_open` int(20) NOT NULL
);

ALTER TABLE `fee`ADD PRIMARY KEY (`f_id`);

INSERT INTO `fee` (`f_id`, `class`,`fee`,`add_open`) VALUES
(223,'LKG','20,000 RS','2025-06-10'),
(224,'UKG','30,000 RS','2025-06-10'),
(225,'1ST','40,000 RS','2025-06-10'),
(226,'2ND','50,000 RS','2025-06-10'),
(227,'3RD','55,000 RS','2025-06-10'),
(228,'4TH','60,000 RS','2025-06-10'),
(229,'5TH','70,000 RS','2025-06-10');


CREATE TABLE `SPORTS` (
  `s_id` int(20) NOT NULL,
    `s_name` varchar(50) NOT null,
  `next_pra` varchar(100) NOT NULL,
    `sports_date` int(20) NOT NULL
   
);

ALTER TABLE `SPORTS` ADD PRIMARY KEY (`s_id`);

INSERT INTO `SPORTS` (`s_id`, `s_name`,`next_pra`,`sports_date`) VALUES
(323,'football','2025-05-01','2025-05-10'),
(324,'Cricket','2025-05-01','2025-05-10'),
(325,'Volleyball','2025-05-01','2025-05-10'),
(326,'Baseball','2025-05-01','2025-05-10');



CREATE TABLE `leav` (
  `s_id` int(20) NOT NULL,
  `s_name` varchar(100) NOT NULL,
  `sp` varchar(100),
  `reason`  varchar(100) NOT NULL,
  `from`varchar(100) NOT NULL,
  `to`varchar(100) NOT NULL
   
); 
INSERT INTO `leav` (`s_id`,`s_name`,`sp`,`reason`,`from`,`to`) VALUES
(1001,'Mahananda','GUN-HOUSE','sick','2024-10-20','2024-10-21'),
(1002,'Siddhant','RMC','sick','2024-10-20','2024-10-21');










CREATE TABLE `homework` (
  `h_id` int(20) NOT NULL,
  `cls_id` varchar(20) NOT NULL,
  `sub_id` varchar(20) NOT NULL,
  `subject` varchar(100) NOT NULL,
  `t_id` int(20) NOT NULL,
  `topic` varchar(100),
  `due_date`  varchar(100) NOT NULL

); 
INSERT INTO `homework` (`h_id`,`cls_id`,`sub_id`,`subject`,`t_id`,`topic`, `due_date`) VALUES
(421,'c103','S101','Kannada',555,'Grammer','2025-10-03'),
(422,'c104','S102','English',666,'Grammer','2025-10-03');



CREATE TABLE `entry` (
  `s_id` int(20) NOT NULL,
  `s_name` varchar(100) ,
  `b_id` int(20) NOT NULL,
  `location` varchar(100) NOT NULL,
  `entry_time` datetime NOT NULL DEFAULT current_timestamp()
  
   
); 

CREATE TABLE `bus` (
  `b_id` int(20) NOT NULL,
    `b_reg` varchar(20) NOT null,
  `route` varchar(100) NOT NULL,
    `c_driverid` int(20) NOT NULL,
    `d_name` varchar(20) NOT NULL
    
); 

ALTER TABLE `bus`
  ADD PRIMARY KEY (`b_id`);
--
-- Dumping data for table `bus`
--

INSERT INTO `bus` (`b_id`, `b_reg`,`route`,`c_driverid`, `d_name`) VALUES
(123,'KL 01 MN 2001','technopark_phase_1',551,'Ramesh'),
(124,'KL 01 MN 2002','chaka',552,'Suresh'),
(125,'KL 01 MN 2003','east_fort',553,'Nagesh');


-- driver table


CREATE TABLE `driver` (
  `d_id` int(20) NOT NULL,
    `d_name` varchar(20) NOT null,
  `route` varchar(100) NOT NULL,
    `dl` varchar(20) NOT NULL,
    `address` varchar(100) NOT NULL,
    `password` varchar(100) NOT NULL
    
); 

ALTER TABLE `driver`
  ADD PRIMARY KEY (`d_id`);
--
-- Dumping data for table `bus`
--

INSERT INTO `driver` (`d_id`, `d_name`,`route`,`dl`, `address`,`password`) VALUES
(551,'Ramesh','technopark_phase_1','DL20221021','#91,Near bus stop trivendrum','rame'),
(552,'Suresh','chaka','DL20221022','#02,Near Railway station  trivendrum','sure'),
(553,'Nagesh','east_fort ','DL20221023','#30,Near police station  trivendrumesh','nage');


CREATE TABLE `leav1` (
  `s_id` int(20) NOT NULL,
  `s_name` varchar(100) NOT NULL,
    `sp` varchar(100),
  `reason`  varchar(100) NOT NULL,
  `from`varchar(100) NOT NULL,
  `to`varchar(100) NOT NULL
   
); 
INSERT INTO `leav1` (`s_id`,`s_name`,`sp`,`reason`,`from`,`to`) VALUES
(1001,'Mahananda','technopark_phase_1','sick','2022-10-20','2022-10-21'),
(1004,'Divya','technopark_phase_1','other','2022-10-28','2022-10-31'),
(1002,'Siddhant','chaka','sick','2022-10-20','2022-10-21');
-- table for student_entry


CREATE TABLE `entry1` (
  `s_id` int(20) NOT NULL,
  `s_name` varchar(100) ,
  `b_id` int(20) NOT NULL,
  `location` varchar(100) NOT NULL,
  `entry_time` datetime NOT NULL DEFAULT current_timestamp()
  
   
); 


--
-- Dumping data for table `student_entry`
--

INSERT INTO `entry1` (`s_id`,`s_name`,`b_id`,`location`,`entry_time`) VALUES
(1001,'Mahananda',123,'technopark_phase_1','2022-10-20 07:51:53'),
(1002,'Siddhant',124,'chaka','2022-10-20 07:52:53'),
(1003,'Navin',125,'east_fort','2022-10-20 07:55:53'),
(1004,'Divya',123,'technopark_phase_1','2022-10-20 07:52:53'),

(1001,'Mahananda',123,'technopark_phase_1','2022-10-22 07:51:53'),

(1002,'Siddhant',124,'chaka','2022-10-23 08:51:53');

CREATE TABLE `exit11` (
  `s_id` int(20) NOT NULL,
  `s_name` varchar(100) ,
  `b_id` int(20) NOT NULL,
  `location` varchar(100) NOT NULL,
  `exit_time` datetime NOT NULL DEFAULT current_timestamp()
  
   
); 


--
-- Dumping data for table `student_entry`
--

INSERT INTO `exit11` (`s_id`,`s_name`,`b_id`,`location`,`exit_time`) VALUES
(1001,'Mahananda',123,'technopark_phase_1','2022-10-20 08:51:53'),
(1002,'Siddhant',124,'chaka','2022-10-20 08:52:53'),
(1003,'Navin',125,'east_fort','2022-10-20 08:55:53'),
(1004,'Divya',123,'stechnopark_phase_1sv','2022-10-20 08:52:53'),
(1005,'Saurabh',124,'chaka','2022-10-20 08:53:53'),
(1006,'Ritvika',125,'east_fort','2022-10-20 08:56:53'),
(1007,'Paranli',123,'technopark_phase_1','2022-10-20 08:50:53'),
(1008,'Prashanthi',124,'chaka','2022-10-20 08:51:53'),
(1001,'Mahananda',123,'technopark_phase_1','2022-10-21 04:51:53'),
(1001,'Mahananda',123,'technopark_phase_1','2022-10-22 08:51:53'),
(1001,'Mahananda',123,'technopark_phase_1','2022-10-23 08:51:53'),
(1002,'Siddhant',124,'chaka','2022-10-21 09:51:53'),
(1002,'Siddhant',124,'chaka','2022-10-22 09:51:53'),

(1002,'Siddhant',124,'chaka','2022-10-23 09:51:53');

