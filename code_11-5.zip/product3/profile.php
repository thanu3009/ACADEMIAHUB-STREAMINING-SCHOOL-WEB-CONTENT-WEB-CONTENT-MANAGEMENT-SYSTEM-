<?php
session_start();
if(!isset($_SESSION['loggedin']) || $_SESSION['loggedin']!=true){
    header("location: login.php");
    exit;
}
?>



<?php
$user="";

include('dbconnect.php');
$user=$_SESSION['username'];
$result = mysqli_query($conn,"SELECT s_name FROM student where s_id='".$user."' " )or die(mysqli_error());
     while($row = mysqli_fetch_array( $result ))
     {
      $user=$row['s_name'];
     }


?>

<?php
$connection = mysqli_connect('localhost', 'root', '', 'test');

?>


<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.css">
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.0/jquery.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.min.js"></script>
    <title>Welcome - <?php echo '<b><font color="green"> ' . $user . '</font></b>';?></title>
    

  
  </head>
  <body>
    <?php require '_nav.php' ?>
    <div class="container my-3">
    <div class="alert alert-success" role="alert">
      <h4 class="alert-heading">Welcome - <?php echo '<b><font color="green">' . $user . '</font></b>';?></h4>
      <hr>
     
    </div>
    

       
<!-- //banner-->

   
	 <p >
		 Under Construction
	 </p>
	 <img src="img/un.jpg" style="width:100%">
		</div>
	
	  
</body>
</html>