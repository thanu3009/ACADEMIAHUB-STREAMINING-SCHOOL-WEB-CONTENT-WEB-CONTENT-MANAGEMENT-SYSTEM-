<?php
	
?>
<?php

   include('dbconnect.php');
   session_start();
   
   if($_SERVER["REQUEST_METHOD"] == "POST") {
     
     

      $id = mysqli_real_escape_string($conn,$_POST['s_id']);
     
      $name = mysqli_real_escape_string($conn,$_POST['s_name']);
	      $sp = mysqli_real_escape_string($conn,$_POST['sp']);
      $res = mysqli_real_escape_string($conn,$_POST['res']);
      $fm = mysqli_real_escape_string($conn,$_POST['from']); 
      $to = mysqli_real_escape_string($conn,$_POST['to']); 
     
  
 
      
	  $sql = "INSERT INTO `studentleav`(`s_id`, `s_name`,`sp`,`reason`, `from`, `to`,`status`) VALUES  ('$id', '$name','$sp', '$res', '$fm', '$to','Pending')";
	  
      $result = mysqli_query($conn,$sql);
   
    echo "<script type='text/javascript'>alert(' Successfully Updated👍 !!');</script>";
    echo "<script type='text/javascript'>window.location='leavemain.php';</script>";
     
   }
?>