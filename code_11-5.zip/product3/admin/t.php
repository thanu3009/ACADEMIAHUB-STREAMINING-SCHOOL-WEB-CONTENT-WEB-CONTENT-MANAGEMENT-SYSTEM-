
<?php
  
//$url = "https://api.thingspeak.com/channels/1910991/feeds.json?api_key=NZ26KHCVWTUZ7JMQ&results=2";
	$url =	"https://api.thingspeak.com/channels/1914460/feeds.json?api_key=JJ44TKSFVFUGODUB&results=2";
$content = file_get_contents($url);
$json = json_decode($content, true);
$data = $json['feeds'][1]['field1'];
echo $data;
   
  
?>