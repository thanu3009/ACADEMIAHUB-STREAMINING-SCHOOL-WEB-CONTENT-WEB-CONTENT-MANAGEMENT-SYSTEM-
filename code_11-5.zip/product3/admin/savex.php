
<?php
   include('dbconnect.php');
   session_start();
   
   if($_SERVER["REQUEST_METHOD"] == "POST") {
     
     

      $id = mysqli_real_escape_string($conn,$_POST['s_id']);
     
      $b_id = mysqli_real_escape_string($conn,$_POST['b_id']);
      $sl = mysqli_real_escape_string($conn,$_POST['location']);
    $result = mysqli_query($conn,"SELECT Stoplocation FROM student where s_id='".$id."' " )or die(mysqli_error());
     while($row = mysqli_fetch_array( $result ))
     {
$tt = $row['Stoplocation'] ;
		 
		
	 }


     if($sl == $tt) 
	 {
		 
	 
  

      
	  $sql = "INSERT INTO `exit1`(`s_id`, `b_id`, `location`) VALUES  ('$id', '$b_id', '$sl')";
	  
      $result = mysqli_query($conn,$sql);
   
    echo "<script type='text/javascript'>alert(' 👍Leave The bus Carefully 🚌  !!');</script>";
    echo "<script type='text/javascript'>window.location='exit.php';</script>";
     
   }
	   else{
 echo "<script type='text/javascript'>alert(' This is not your Stop 😔 Your Stop Is $tt  !!');</script>";
 echo "<script type='text/javascript'>window.location='exit.php';</script>";
     
	   }
   }
   
?>