<?php
	
?>
<?php
   include('dbconnect.php');
   session_start();
   
   if($_SERVER["REQUEST_METHOD"] == "POST") {
     
     

      $id = mysqli_real_escape_string($conn,$_POST['s_id']);
     
      $name = mysqli_real_escape_string($conn,$_POST['s_name']);
      $sl = mysqli_real_escape_string($conn,$_POST['Stoplocation']);
      $add = mysqli_real_escape_string($conn,$_POST['address']); 
   //   $cid = mysqli_real_escape_string($conn,$_POST['cid']); 
      $pswd = mysqli_real_escape_string($conn,$_POST['password']); 
     

     
	  $sql = "INSERT INTO `teacher`(`t_id`, `t_name`, `subject`, `qulification`, `password`)
      VALUES
        ('$id', '$name', '$sl', '$add', '$pswd')";
	  
      $result = mysqli_query($conn,$sql);
   
    echo "<script type='text/javascript'>alert(' New Teacher Data Saved Successfully !!');</script>";
    echo "<script type='text/javascript'>window.location='autho.php';</script>";
     
   }
?>