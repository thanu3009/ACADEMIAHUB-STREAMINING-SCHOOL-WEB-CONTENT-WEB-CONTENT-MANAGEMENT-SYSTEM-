<?php
#	$_SESSION ='';
?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.css">
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.0/jquery.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.min.js"></script>
    <title>Welcome - <?php $_SESSION['username']?></title>

  </head>
 <body>
   <?php require '_nav.php' ?>
    <div class="container my-3">
    <div class="alert alert-success" role="alert">
      <h4 class="alert-heading">Hello Admin  - Enter the TEACHER details carefully</h4>
          <br><hr>
          <form method="post" action="savedatatech.php">
            <div class="mb-3">
     
            
            <div class="mb-3">
                <label>TEACHER ID:</label>
                <input type="text" class="form-control" id="s_id" name="s_id" placeholder ="Example : Tech007">
            </div>
            
           <br/>
			  <div class="mb-3">
                <label>TEACHER Name:</label>
                <input type="text" class="form-control" id="s_name" name="s_name">

            </div>
           <br/>
					  <div class="mb-3">
                <label>Experience in Subject:</label>
                <input type="text" class="form-control" id="Stoplocation" name="Stoplocation">

            </div>
           <br/>
			<div class="mb-3">
                <label>Educational Qualifications :</label>
                <input type="text" class="form-control" id="address" name="address">

            </div>
          
           

				<div class="mb-3">
                <label>Set Password:</label>
                <input type="text" class="form-control" id="password" name="password">

            </div>
           <br/>
          
                        <button type="Save" class="btn btn-primary">SAVE TEACHER DATA</button>
                        <button type="reset" class="btn btn-primary">Clear</button>    
            </div>
           
     
    </form>
    </div>
    







  </div>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
  </body>
</html>
