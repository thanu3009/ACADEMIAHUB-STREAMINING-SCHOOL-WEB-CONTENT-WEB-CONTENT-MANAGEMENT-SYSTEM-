
<?php
   include('dbconnect.php');
   session_start();
   
   if($_SERVER["REQUEST_METHOD"] == "POST") {
     
     

      $id = mysqli_real_escape_string($conn,$_POST['s_id']);
     
      $b_id = mysqli_real_escape_string($conn,$_POST['b_id']);
      $sl = mysqli_real_escape_string($conn,$_POST['location']);
     $result = mysqli_query($conn,"SELECT b_id FROM bus where route='".$sl."' " )or die(mysqli_error());
     while($row = mysqli_fetch_array( $result ))
     {
$tt = $row['b_id'] ;
		
	 }


     if($b_id == $tt) 
	 {
		 
	 
  

      
	  $sql = "INSERT INTO `entry`(`s_id`, `b_id`, `location`) VALUES  ('$id', '$b_id', '$sl')";
	  
      $result = mysqli_query($conn,$sql);
   
    echo "<script type='text/javascript'>alert(' Carefully Enter The Bus 🚌 , Door will Open !!');</script>";
    echo "<script type='text/javascript'>window.location='autho.php';</script>";
     
   }
	   else{
		    
 echo "<script type='text/javascript'>alert(' This is not your BUS, Find Your Bus !! Your Bus ID Is $tt ');</script>";
 echo "<script type='text/javascript'>window.location='autho.php';</script>";
     
	   }
   }
   
?>