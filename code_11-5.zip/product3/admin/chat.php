<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.css">
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.0/jquery.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.min.js"></script>
    <title>Welcome - <?php $_SESSION['username']?></title>
    <!-- <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    -->
    <style type="text/css">
      
.profile-container {
            display: flex;
            align-items: center;
            gap: 20px;
            background-color: #f9f9f9;
            border: 2px solid #ccc;
            border-radius: 10px;
            padding: 20px;
            max-width: 600px;
            margin: 50px auto;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }

        .profile-photo {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            object-fit: cover;
            border: 3px solid #4CAF50;
        }

        .profile-title {
            font-size: 24px;
            color: #333;
            font-weight: bold;
            font-family: Arial, sans-serif;
        }

        .profile-description {
            font-size: 16px;
            color: #666;
            font-family: Arial, sans-serif;
            margin-top: 10px;
        }
      
form.example input[type=text] {
  padding: 10px;
  font-size: 17px;
  border: 1px solid grey;
  float: left;
  width: 100%;
  background: #f1f1f1;
}

form.example button {

  width: 50%;
  padding: 5px;
  background: #2196F3;
  color: white;
  font-size: 17px;
  border: 1px solid rgb(0, 0, 0);
  border-left: none;
  cursor: pointer;
}
form.example button {

width: 50%;
padding: 5px;
background: #2196F3;
color: white;
font-size: 17px;
border: 1px solid rgb(0, 0, 0);
border-left: none;
cursor: pointer;
}
.button {
  background-color: #4CAF50;
  border: none;
  left: 35%;
  
  position: relative;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}
    
    
    </style>
  </head>
  <body>
 <?php require '_nav.php' ?> 
    <div class="container my-3">
    <div class="alert alert-success" role="alert">
      <!-- <h4 class="alert-heading">Welcome - Admin </h4>
      <hr> -->
     
    </div>
 

       
    <div class="profile-container">
        <img src="img/feeb.jpg" alt="Profile Photo" class="profile-photo">
        <div>
            <div class="profile-title">Feedback</div>
            <!-- Navigating safely, nurturing futures. -->
            <!-- <div class="profile-description">Navigating safely, nurturing futures..</div>
            <div class="profile-description"><a href="adddriver.php">Click here to add new DRIVER to our School.</a></div>
         -->
          </div>
    </div>


  <!--/banner-->
  <div class="banner-wthree-info container">
        <div class="row">
            <div class="col-lg-5 banner-left-info">
                
               
         
    </div>
</div>

<!-- //banner-->
<table class="table table-striped table-dark">
  <thead>
    <tr>
    <th scope="col">  DATE</th>
        <th scope="col">  ID</th>
		<th scope="col">  NAME</th>
		<th scope="col">  Comments</th>
		
		
	</tr>
  </thead>
    <?php
   
     include('dbconnect.php');
    // session_start();
    //  $id=$_SESSION['username'];
    //  $result = mysqli_query($conn,"SELECT * FROM student_activity where s_id='".$id."' " )or die(mysqli_error());
   
     $result = mysqli_query($conn,"SELECT * FROM feedback" )or die(mysqli_error());
     while($row = mysqli_fetch_array( $result ))
     {
       echo "<tr align='center'>";
       
      
       echo '<td><b><font color="white">' . $row['timestamp'] . '</font></b></td>';
	 
       echo '<td><b><font color="white">' . $row['uid'] . '</font></b></td>';
       echo '<td><b><font color="white">' . $row['name'] . '</font></b></td>';
       echo '<td><b><font color="white">' . $row['comments'] . '</font></b></td>';
       
       echo'<td> <a href="reply.php?id=' . $row['id'] . '" ><button type="Submit" style="background-color:green; color:white;">Response</button></a></td>';
       echo'<td> <a href="delcom.php?id=' . $row['id'] . '" ><button type="Submit" style="background-color:red; color:white;">Delete</button></a></td>';
    
    
   

       echo "</tr>";
                            }
                        
                            ?>        
                                                        
                                                    </tbody>
                                                    
                                                </table> 

   
   <p></p>
    
     
   



       
    <!-- js -->
 
    
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.3/dist/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
</body>
</html>
	