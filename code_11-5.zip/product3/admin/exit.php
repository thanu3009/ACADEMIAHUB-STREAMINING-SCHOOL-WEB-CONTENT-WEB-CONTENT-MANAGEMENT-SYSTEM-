<!doctype html>
<?php
$user="";

include('dbconnect.php');
$user=$_SESSION['username'];
?>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.css">
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.0/jquery.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.min.js"></script>
    <title>Welcome - <?php $_SESSION['username']?></title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
   
    <style type="text/css">
		.btn-group button {
  background-color: #04AA6D; /* Green background */
  border: 1px solid green; /* Green border */
  color: black; /* White text */
  padding: 10px 24px; /* Some padding */
  cursor: pointer; /* Pointer/hand icon */
  float: left; /* Float the buttons side by side */
}

/* Clear floats (clearfix hack) */
.btn-group:after {
  content: "";
  clear: both;
  display: table;
}

.btn-group button:not(:last-child) {
  border-right: none; /* Prevent double borders */
}

/* Add a background color on hover */
.btn-group button:hover {
  background-color: #3e8e41;
}


      
form.example input[type=text] {
  padding: 10px;
  font-size: 17px;
  border: 1px solid grey;
  float: left;
  width: 100%;
  background: #f1f1f1;
}

form.example button {

  width: 50%;
  padding: 5px;
  background: #2196F3;
  color: white;
  font-size: 17px;
  border: 1px solid rgb(0, 0, 0);
  border-left: none;
  cursor: pointer;
}
		
.form-inline {  
  display: flex;
  flex-flow: row wrap;
  align-items: center;
}



.form-inline input {
  vertical-align: middle;
  margin: 5px 10px 5px 0;
  padding: 10px;
  background-color: #fff;
  border: 1px solid #ddd;
}

.form-inline button {
  padding: 10px 20px;
  background-color: dodgerblue;
  border: 1px solid #ddd;
  color: white;
  cursor: pointer;
}

.form-inline button:hover {
  background-color: royalblue;
}

@media (max-width: 800px) {
  .form-inline input {
    margin: 10px 0;
  }
  
  .form-inline {
    flex-direction: column;
    align-items: stretch;
  }
}
 
    
    </style>
  </head>
  <body>
   <?php require '_nav.php' ?>
    
    <div class="container my-3">
    <div class="alert alert-success" role="alert">
      <h4 class="alert-heading">Welcome - Admin </h4>
      <hr>
      
    </div>
    <br/>
  <!--/banner-->
  <div class="banner-wthree-info container">
        <div class="row">
            <div class="col-lg-5 banner-left-info">
                
               
         
    </div>
</div>

<!-- //banner-->
	  		
<div class="btn-group">
  <button >ALL</button>
		<a href="autho.php">
			<button >Entry</button></a>
	<a href="exit.php">
  <button style="background-color:yellow;">Exit</button></a>
</div>
	  <?php	  
$url =	"https://api.thingspeak.com/channels/1914460/feeds.json?api_key=JJ44TKSFVFUGODUB&results=2";
$content = file_get_contents($url);
$json = json_decode($content, true);
$data = $json['feeds'][1]['field1'];
$busid="";
$loc= "technopark_phase_1";
	
		
		if($data == '1001' || $data == '1004' || $data == '1007' )
		{
			$busid='123';
		}
		
		if($data == '1006' || $data == '1003' )
		{
			$busid='125';
		}
		if($data == '1002' || $data == '1005' || $data == '1008')
		{
			$busid='124';
		}
?>
	  

	  
<form class="form-inline" method="post" action="savex.php">
	<div class="mb-3">
                <label>Student ID:</label>
  <input type="number" id="s_id" placeholder="Enter Student ID" name="s_id" value="<?php echo '' . $data . '';?>" >
	</div>
	<div class="mb-3">
                <label>BUS ID:</label>
  <input type="number" id="b_id" placeholder="Enter Bus ID" name="b_id" value="<?php echo '' . $busid . '';?>" >
	</div>
	<div class="mb-3">
                <label>Student Stop Location:</label>
  <input type="text" id="location" placeholder="Enter The Location" name="location"  value="<?php echo '' . $loc . '';?>" >
	</div>
  <label>
	  
 
  </label>
  <button type="submit">Exit From The Bus</button>
</form>
	  
<div class="">
      <P></P>
      <form class="example" method="post" style="margin:auto;max-width:300px">
          <input type="number" placeholder="Enter Student ID" id="search1" name="search1" required value="<?php echo '' . $data . '';?>">
          
<input type="submit" name="submit">
       
        </form>
   
    </div>
    <p></p>
    <table class="table table-striped table-dark">
  <thead>
    <tr>
     
      <th scope="col">  STUDENT ID</th>
      <!-- <th scope="col">  STUDENT NAME</th> -->
      <th scope="col">  BUS ID</th>
      <th scope="col">  LOCATION</th>
      <!-- <th scope="col">  BUS ENTER TIME</th> -->
      <th scope="col">  BUS EXIT TIME</th>
    </tr>
  </thead>
    <?php
     $id="";
     include('dbconnect.php');
		


    // session_start();
    //  $id=$_SESSION['username'];
    //  $result = mysqli_query($conn,"SELECT * FROM student_activity where s_id='".$id."' " )or die(mysqli_error());
    if (isset($_POST["submit"])) {
        $id = $_POST["search1"];
     $result = mysqli_query($conn,"SELECT * FROM exit1 where s_id='".$id."' " )or die(mysqli_error());
     while($row = mysqli_fetch_array( $result ))
     {
       echo "<tr align='center'>";
       
      
       
       echo '<td><b><font color="white">' . $row['s_id'] . '</font></b></td>';
      
       // echo '<td><b><font color="white">' . $row['s_name'] . '</font></b></td>';
       echo '<td><b><font color="white">' . $row['b_id'] . '</font></b></td>';
       echo '<td><b><font color="white">' . $row['location'] . '</font></b></td>';
       // echo '<td><b><font color="white">' . $row['entry_time'] . '</font></b></td>';
       echo '<td><b><font color="white">' . $row['exit_time'] . '</font></b></td>';
   

       echo "</tr>";
                            }
                        }
                            ?>        
                                                        
                                                    </tbody>
                                                    
                                                </table> 

   
   <p></p>
    
     
   



       
    <!-- js -->
 
    
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.3/dist/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
</body>
</html>