<?php
   include('dbconnect.php');
   session_start();
   $le_id='';
   
   if($_SERVER["REQUEST_METHOD"] == "GET") {
    $le_id = mysqli_real_escape_string($conn,$_GET['id']); 
	  
	  $sql = "update studentleav set status='Rejected' where le_id='$le_id'";	  
	  echo $sql;
      $result = mysqli_query($conn,$sql);
	  
	
	echo "<script type='text/javascript'>alert('Leave has been rejected');</script>";
	echo "<script type='text/javascript'>window.location='Leavest.php';</script>";
	 }
	

   //}
?>