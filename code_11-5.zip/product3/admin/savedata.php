<?php
	
?>
<?php
   include('dbconnect.php');
   session_start();
   
   if($_SERVER["REQUEST_METHOD"] == "POST") {
     
     

      $id = mysqli_real_escape_string($conn,$_POST['s_id']);
     
      $name = mysqli_real_escape_string($conn,$_POST['s_name']);
      $sl = mysqli_real_escape_string($conn,$_POST['Stoplocation']);
      $add = mysqli_real_escape_string($conn,$_POST['address']); 
      $cid = mysqli_real_escape_string($conn,$_POST['cid']); 
      $pswd = mysqli_real_escape_string($conn,$_POST['password']); 
     
  
$clsname = '';
$result = mysqli_query($conn,"SELECT c_name FROM cls where c_id='".$cid."' " )or die(mysqli_error());
     while($row = mysqli_fetch_array( $result ))
     {
      $clsname=$row['c_name'];
     }
     
	  $sql = "INSERT INTO `student`(`s_id`, `s_name`, `Stoplocation`, `address`, `password`,`class`,`c_id`)
      VALUES
        ('$id', '$name', '$sl', '$add', '$pswd', '$clsname','$cid')";
	  
      $result = mysqli_query($conn,$sql);
   
    echo "<script type='text/javascript'>alert(' New Student Data Saved Successfully !!');</script>";
    echo "<script type='text/javascript'>window.location='student.php';</script>";
     
   }
?>