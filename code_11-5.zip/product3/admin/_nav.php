<?php 
?>
<html>

	<head>
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
		
	</head>
	<body>
		
  <?php

include('dbconnect.php');
    // session_start();
    //  $id=$_SESSION['username'];
    //  $result = mysqli_query($conn,"SELECT * FROM student_activity where s_id='".$id."' " )or die(mysqli_error());
   
     $result = mysqli_query($conn,"SELECT * FROM   schools" )or die(mysqli_error());
     while($row = mysqli_fetch_array( $result ))
     {
        $name='';

        $name =  $row['s_name'];
     }
        ?>

	<?php
echo '<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <a class="navbar-brand" >'.$name.'</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item ">
        <a class="nav-link" href="adminhome.php"><i class="fa fa-home" aria-hidden="true"> Home </i> <span class="sr-only">(current)</span></a>
      </li>';

      echo '<li class="nav-item">
      <a class="nav-link" href="autho.php"><i class="fa fa-address-book-o" aria-hidden="true"> ADMINISTRATIVE</i></a>
     </li>';
 
     
     echo '<li class="nav-item ">
     <a class="nav-link" href="student.php"><i class="fa fa-users" aria-hidden="true"> STUDENT</i></a>
    </li>';

  echo '<li class="nav-item ">
     <a class="nav-link" href="Leavest.php"><i class="fa fa-book" aria-hidden="true"> ALL LEAVE</i></a>
    </li>';

    echo '<li class="nav-item">
    <a class="nav-link" href="bus.php"><i class="fa fa-bus" aria-hidden="true"> BUS</i></a>
   </li>';

   echo '<li class="nav-item">
   <a class="nav-link" href="driver.php"><i class="fa fa-id-card-o" aria-hidden="true"> DRIVER</i></a>
  </li>';
  echo '<li class="nav-item ">
  <a class="nav-link" href="chat.php"><i class="fa fa-book" aria-hidden="true"> FEEDBACK</i></a>
 </li>';

      echo '<li class="nav-item">
      <a class="nav-link" href="../logout.php"><i class="fa fa-sign-out" aria-hidden="true"> LOGOUT</i></a>
    </li>';
    
       
      
    echo '</ul>
  
  </div>
</nav>';
?>