
<?php
   include('dbconnect.php');
   session_start();
   
   if($_SERVER["REQUEST_METHOD"] == "POST") {
     
     

      $sname = mysqli_real_escape_string($conn,$_POST['s_name']);
      $sid = mysqli_real_escape_string($conn,$_POST['s_id']);
     
      $lc = mysqli_real_escape_string($conn,$_POST['lc']);
      $ch = mysqli_real_escape_string($conn,$_POST['chname']);
      $add = mysqli_real_escape_string($conn,$_POST['address']); 

    
      $sql = "UPDATE schools set s_name = '$sname' where s_id = '$sid' ";

     //$sql = " UPDATE schools set s_name = '$sname' , licence_no = '$lc' , current_chairman = '$ch' , s_address = '$add' where s_name = '$sname' ";

	  
      $result = mysqli_query($conn,$sql);
   
    echo "<script type='text/javascript'>alert(' School data updated Successfully !!');</script>";
    echo "<script type='text/javascript'>window.location='adminhome.php';</script>";
     
   }
?>