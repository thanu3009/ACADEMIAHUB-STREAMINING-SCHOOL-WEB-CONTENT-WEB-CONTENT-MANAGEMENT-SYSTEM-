<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.css">
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.0/jquery.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.min.js"></script>
    <title>Welcome - <?php $_SESSION['username']?></title>
    <!-- <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
     -->
    <style>


.profile-container {
            display: flex;
            align-items: center;
            gap: 20px;
            background-color: #f9f9f9;
            border: 2px solid #ccc;
            border-radius: 10px;
            padding: 20px;
            max-width: 600px;
            margin: 50px auto;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }

        .profile-photo {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            object-fit: cover;
            border: 3px solid #4CAF50;
        }

        .profile-title {
            font-size: 24px;
            color: #333;
            font-weight: bold;
            font-family: Arial, sans-serif;
        }

        .profile-description {
            font-size: 16px;
            color: #666;
            font-family: Arial, sans-serif;
            margin-top: 10px;
        }

.feedback-container {
    
    align-items: center;
    background: white;
    border-radius: 10px;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    padding: 20px;
    text-align: center;
}

h1 {
    margin-bottom: 20px;
    color: #333;
}

input, textarea {
    width: calc(100% - 20px);
    margin: 10px;
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 5px;
}

button {
    width: 100%;
    padding: 10px;
    background-color: #28a745;
    color: white;
    border: none;
    border-radius: 5px;
    cursor: pointer;
}

button:hover {
    background-color: #218838;
}
.btn-group button {
  background-color: #04AA6D; /* Green background */
  border: 1px solid green; /* Green border */
  color: black; /* White text */
  padding: 10px 24px; /* Some padding */
  cursor: pointer; /* Pointer/hand icon */
  float: left; /* Float the buttons side by side */
}

/* Clear floats (clearfix hack) */
.btn-group:after {
  content: "";
  clear: both;
  display: table;
}

.btn-group button:not(:last-child) {
  border-right: none; /* Prevent double borders */
}

/* Add a background color on hover */
.btn-group button:hover {
  background-color: #3e8e41;
}
		.active, .btn:hover {
  background-color: #666;
  color: white;
}
</style>
  </head>
  <body>
  
 <?php require '_nav.php' ?>
 <div class="profile-container">
        <img src="../img/tech.jpg" alt="Profile Photo" class="profile-photo">
        <div>
            <div class="profile-title">Feedback</div>
            <div class="profile-description"><a href="addtech.php">We Value Your Feedback</a></div>
        </div>
    </div>
 <div class="feedback-container">

 <?php
   include("config.php");
   
   
     if($_SERVER["REQUEST_METHOD"] == "GET") {
        $id = mysqli_real_escape_string($db,$_GET['id']); 
     }
   $result = mysqli_query($conn,"SELECT * FROM feedback where id = '$id' " )or die(mysqli_error());
   while($row = mysqli_fetch_array( $result ))
   {
   
      $date = $row['timestamp']; 
   
      $uid = $row['uid'] ;
      $name = $row['name']; 
      $cmd = $row['comments']; 
   }
     
                          ?>        
  
        <h1>We Value Your Feedback</h1>
        <form action="feedrly.php" method="POST">
     
        <input type="text" name="fid"   value="<?php echo '' . $id  . '';?>"  >
            <input type="text" name="name"   value="<?php echo '' . $name. '';?>"  >
         
             <input type="text" name="uid" value="<?php echo '' . $uid. '';?>"  >
            <input type="text" name="cmd" value="<?php echo '' . $cmd. '';?>"  > </textarea>
            <textarea name="Reply" name="rly" placeholder="Your Comments, our response" ></textarea>
            <button type="submit">Submit</button>
        </form>
    </div>
   
 
    
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.3/dist/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
</body>
</html> 