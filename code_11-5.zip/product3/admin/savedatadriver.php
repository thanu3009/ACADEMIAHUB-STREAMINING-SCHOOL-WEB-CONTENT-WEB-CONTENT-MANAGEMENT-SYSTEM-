<?php
	
?>
<?php
   include('dbconnect.php');
   session_start();
   
   if($_SERVER["REQUEST_METHOD"] == "POST") {
     
     

      $id = mysqli_real_escape_string($conn,$_POST['d_id']);
     
      $name = mysqli_real_escape_string($conn,$_POST['d_name']);
      $sl = mysqli_real_escape_string($conn,$_POST['route']);
      $add = mysqli_real_escape_string($conn,$_POST['dl']); 
     $cid = mysqli_real_escape_string($conn,$_POST['add']); 
      $pswd = mysqli_real_escape_string($conn,$_POST['password']); 
     

     
	  $sql = "INSERT INTO `driver`(`d_id`, `d_name`, `route`, `dl`, `address`,`password`)
      VALUES
        ('$id', '$name', '$sl', '$add', '$cid', '$pswd')";
	  
      $result = mysqli_query($conn,$sql);
   
    echo "<script type='text/javascript'>alert(' New Driver Data Saved Successfully !!');</script>";
    echo "<script type='text/javascript'>window.location='driver.php';</script>";
     
   }
?>