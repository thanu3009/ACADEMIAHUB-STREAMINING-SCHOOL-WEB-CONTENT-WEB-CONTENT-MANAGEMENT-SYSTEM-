<?php
   include("config.php");
   session_start();
   
     if($_SERVER["REQUEST_METHOD"] == "GET") {
	  
	  $id = mysqli_real_escape_string($db,$_GET['id']); 
	  
	  $sql = "DELETE FROM studentleav  where le_id='$id'";	  
	  echo $sql;
      $result = mysqli_query($db,$sql);
	  
	
	echo "<script type='text/javascript'>alert('Leave Record has been Deleted');</script>";
	echo "<script type='text/javascript'>window.location='Leavest.php';</script>";
	 }
	

   //}
?>