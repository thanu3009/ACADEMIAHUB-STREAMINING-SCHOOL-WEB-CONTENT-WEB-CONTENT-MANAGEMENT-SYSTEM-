<?php
   include("config.php");
   session_start();
   
     if($_SERVER["REQUEST_METHOD"] == "GET") {
	  
	  $id = mysqli_real_escape_string($db,$_GET['id']); 
	  
	  $sql = "update studentleav set status='Approved' where le_id='$id'";	  
	  echo $sql;
      $result = mysqli_query($db,$sql);
	  
	
	echo "<script type='text/javascript'>alert('Leave has been Appoved');</script>";
	echo "<script type='text/javascript'>window.location='Leavest.php';</script>";
	 }
	

   //}
?>