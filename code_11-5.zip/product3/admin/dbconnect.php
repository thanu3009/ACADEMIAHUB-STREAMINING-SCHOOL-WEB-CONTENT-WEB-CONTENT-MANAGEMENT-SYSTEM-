<?php
$server = "localhost";
$username = "root";
$password = "";
$database = "tj_schools";

$conn = mysqli_connect($server, $username, $password, $database);


?>
