<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.css">
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.0/jquery.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.min.js"></script>
    <title>Welcome - <?php $_SESSION['username']?></title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
   
    <style type="text/css">
     
.button {
  background-color: #4CAF50;
  border: none;
  left: 35%;
  
  position: relative;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}

form.example input[type=text] {
  padding: 10px;
  font-size: 17px;
  border: 1px solid grey;
  float: left;
  width: 100%;
  background: #f1f1f1;
}

form.example button {

  width: 50%;
  padding: 5px;
  background: #2196F3;
  color: white;
  font-size: 17px;
  border: 1px solid rgb(0, 0, 0);
  border-left: none;
  cursor: pointer;
}
 
    
    </style>
  </head>
  <body>
   <?php require '_nav.php' ?>
    
    <div class="container my-3">
    <div class="alert alert-success" role="alert">
      <h4 class="alert-heading">MARKS CARD </h4>
      <hr>
    
    </div>
    <br/>
  <!--/banner-->
  <div class="banner-wthree-info container">
        <div class="row">
            <div class="col-lg-5 banner-left-info">
                
               
         
    </div>
</div>

<!-- //banner-->
<a href="editmarkscard.php" class="button ">EDIT MARKS CARD</a>
<table class="table table-striped table-dark">
  <thead>
    <tr>
     
      <th scope="col">  Class ID</th>
      <th scope="col">  Class NAME</th>
      <th scope="col">  Subject Name</th>
      <th scope="col"> Marks Assigned</th>
      <th scope="col">  Marks Earned</th>
    

		 <!-- <th scope="col">  ADDRESS</th> -->
    
    </tr>
  </thead>
  <?php
  
   if (isset($_GET['id'])) { 
       $data = $_GET['id']; 
       //   echo hi;
      // echo $data; // Outputs: Hello, World! 
   } 
 
   include('dbconnect.php');
  // session_start();
  //  $id=$_SESSION['username'];
  //  $result = mysqli_query($conn,"SELECT * FROM student_activity where s_id='".$id."' " )or die(mysqli_error());
 
   $result = mysqli_query($conn,"SELECT * FROM markscard  " )or die(mysqli_error());
   while($row = mysqli_fetch_array( $result ))
   {
     echo "<tr align='center'>";
     
    
     
     echo '<td><b><font color="white">' . $row['cls_id'] . '</font></b></td>';
    
     echo '<td><b><font color="white">' . $row['cls_name'] . '</font></b></td>';
   
     echo '<td><b><font color="white">' . $row['subject'] . '</font></b></td>';
    echo '<td><b><font color="white">' . $row['max_marks'] . '</font></b></td>';
       
    echo '<td><b><font color="white">' . $row['Marks'] . '</font></b></td>';
//       echo'<td> <a href="markscard.php?id=' . $row['Marks'] . '" ><button type="Submit" style="background-color:green; color:white;">Marks card</button></a></td>';
       //echo'<td> <a href="stuloc.php?id=' . $row['s_id'] . '" ><button type="Submit" style="background-color:green; color:white;">Attendnance </button></a></td>';
      // echo'<td> <a href="stuloc.php?id=' . $row['s_id'] . '" ><button type="Submit" style="background-color:green; color:white;">Location</button></a></td>';
  
 

     echo "</tr>";
                          }
                      
                          ?>        
                                                      
                                                  </tbody>
                                                  
                                              </table> 

 
 <p></p>
  
   
 



     
  <!-- js -->

  
  <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.3/dist/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
</body>
</html>