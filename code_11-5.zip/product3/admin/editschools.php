<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.css">
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.0/jquery.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.min.js"></script>
    <title>Welcome - <?php $_SESSION['username']?></title>
<style>



.profile-container {
            display: flex;
            align-items: center;
            gap: 20px;
            background-color: #f9f9f9;
            border: 2px solid #ccc;
            border-radius: 10px;
            padding: 20px;
            max-width: 600px;
            margin: 50px auto;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }

        .profile-photo {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            object-fit: cover;
            border: 3px solid #4CAF50;
        }

        .profile-title {
            font-size: 24px;
            color: #333;
            font-weight: bold;
            font-family: Arial, sans-serif;
        }

        .profile-description {
            font-size: 16px;
            color: #666;
            font-family: Arial, sans-serif;
            margin-top: 10px;
        }
* {box-sizing: border-box;}

.mySlides {display: none;}
img {vertical-align: middle;}

/* Slideshow container */
.slideshow-container {
  max-width: 1000px;
  position: relative;
  margin: auto;
}

/* Caption text */
.text {
 background-color:white;
  color: black;
  font-size: 15px;
  padding: 15px 12px;
  position: absolute;
  bottom: -20px;
  width: 100%;
  text-align: center;
}

/* Number text (1/3 etc) */
.numbertext {
  color: #f2f2f2;
  font-size: 12px;
  padding: 8px 12px;
  position: absolute;
  top: 0;
}

/* The dots/bullets/indicators */
.dot {
  height: 15px;
  width: 15px;
  margin: 0 2px;
  background-color: #bbb;
  border-radius: 50%;
  display: inline-block;
  transition: background-color 0.6s ease;
}

.active {
  background-color: #717171;
}

/* Fading animation */
.fade {
  animation-name: fade;
  animation-duration: 1.5s;
}

@keyframes fade {
  from {opacity: .4} 
  to {opacity: 1}
}

/* On smaller screens, decrease text size */
@media only screen and (max-width: 300px) {
  .text {font-size: 11px;
	color:black;}
}
	
	
	
.form-inline {  
  display: flex;
  flex-flow: row wrap;
  align-items: center;
}



.form-inline input {
  vertical-align: middle;
  margin: 5px 10px 5px 0;
  padding: 10px;
  background-color: #fff;
  border: 1px solid #ddd;
}

.form-inline button {
  padding: 10px 20px;
  background-color: dodgerblue;
  border: 1px solid #ddd;
  color: white;
  cursor: pointer;
}

.form-inline button:hover {
  background-color: royalblue;
}

@media (max-width: 800px) {
  .form-inline input {
    margin: 10px 0;
  }
  
  .form-inline {
    flex-direction: column;
    align-items: stretch;
  }
}
</style>
  </head>
  <body>
    <?php require '_nav.php' ?>
    
    <div class="container my-3">


    <!-- <div class="profile-container">
        <img src="img/school.jpg" alt="Profile Photo" class="profile-photo">
        <div>
            <div class="profile-title">TJ Educational Society </div>
            <div class="profile-description"><a href="editschools.php">Click here to Update School name.</a></div>
        </div>
        
    </div> -->
    
    <div class="profile-container">
        <img src="img/admin.jpg" alt="Profile Photo" class="profile-photo">
        <div>
            <div class="profile-title">ADMINISTRATOR  </div>
            <div class="profile-description"><a href="addstu.php">Click here to Update Admin Password name.</a></div>
        </div>
        
    </div>


  <!--/banner-->
  <div class="container my-3">
  <div class="alert alert-success" role="alert">

          <form method="post" action="saveschooldata.php">
            <div class="mb-3">

            <?php

include('dbconnect.php');
    // session_start();
    //  $id=$_SESSION['username'];
    //  $result = mysqli_query($conn,"SELECT * FROM student_activity where s_id='".$id."' " )or die(mysqli_error());
   
     $result = mysqli_query($conn,"SELECT * FROM   schools" )or die(mysqli_error());
     while($row = mysqli_fetch_array( $result ))
     {
        $name='';
        $LC='';
        $Cname='';
        $add='';

        $name =  $row['s_name'];
        $LC=$row['licence_no'];
        $Cname =  $row['current_chairman'];
        $add=$row['s_address'];
        $s_id=$row['s_id'];

     }
            ?>

			  <div class="mb-3">
                <label>School Name:</label>
                <input type="text" class="form-control" id="s_id" name="s_id" value="<?php echo '' . $s_id . '';?>">
                <input type="text" class="form-control" id="s_name" name="s_name" value="<?php echo '' . $name . '';?>" >

            </div>
           <br/>
           <div class="mb-3">
                <label>School License Number:</label>
                <input type="text" class="form-control" id="lc" name="lc" value="<?php echo '' . $LC . '';?>" >

            </div>
            <br/>
					  <div class="mb-3">
                <label>Current Chairman Name:</label>
                <input type="text" class="form-control" id="chname" name="chname" value="<?php echo '' . $Cname . '';?>" >

            </div>
           <br/>
			<div class="mb-3">
                <label>School Address:</label>
                <input type="text" class="form-control" id="address" name="address" value="<?php echo '' . $add . '';?>" >

            </div>

          
                        <button type="Save" class="btn btn-primary">Update</button>
                        <button type="reset" class="btn btn-primary">Clear</button>    
            </div>
           
     
    </form>
    </div>
    







  </div>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
  </body>
</html>
