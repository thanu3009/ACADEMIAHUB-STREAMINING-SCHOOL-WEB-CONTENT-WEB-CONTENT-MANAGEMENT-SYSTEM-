
<?php
   include('dbconnect.php');
   session_start();
   
   if($_SERVER["REQUEST_METHOD"] == "POST") {
     
     

      $fid = mysqli_real_escape_string($conn,$_POST['fid']);

      $reply = mysqli_real_escape_string($conn,$_POST['Reply']); 

    
      $sql = "UPDATE feedback set reply = '$reply' where id = '$fid' ";

     //$sql = " UPDATE schools set s_name = '$sname' , licence_no = '$lc' , current_chairman = '$ch' , s_address = '$add' where s_name = '$sname' ";

	  
      $result = mysqli_query($conn,$sql);
   
    echo "<script type='text/javascript'>alert(' Comment Response updated Successfully !!');</script>";
    echo "<script type='text/javascript'>window.location='chat.php';</script>";
     
   }
?>