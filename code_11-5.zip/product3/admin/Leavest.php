<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.css">
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.0/jquery.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.min.js"></script>
    <title>Welcome - <?php $_SESSION['username']?></title>
    <!-- <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    -->
    <style type="text/css">


.button-container {
            display: flex;
            gap: 20px;
        }

        .button {
            padding: 10px 20px;
            font-size: 16px;
            font-weight: bold;
            color: white;
            text-transform: uppercase;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2);
            transition: transform 0.2s, box-shadow 0.2s;
        }

        .button:hover {
            transform: scale(1.1);
            box-shadow: 0 6px 8px rgba(0, 0, 0, 0.3);
        }

        .btn-primary {
            background-color: #4CAF50;
        }

        .btn-secondary {
            background-color: #2196F3;
        }

        .btn-danger {
            background-color: #f44336;
        }
      
form.example input[type=text] {
  padding: 10px;
  font-size: 17px;
  border: 1px solid grey;
  float: left;
  width: 100%;
  background: #f1f1f1;
}

form.example button {

  width: 50%;
  padding: 5px;
  background: #2196F3;
  color: white;
  font-size: 17px;
  border: 1px solid rgb(0, 0, 0);
  border-left: none;
  cursor: pointer;
}
 
.small-output-box {
  
  font-size: 14px;
  color: #333;
  background-color: #ffffff;
  border: 2px solid #4CAF50;
  border-radius: 8px;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2);
  overflow-y: auto; /* Adds scroll for long text */
}
    
    </style>
  </head>
  <body>
 <?php require '_nav.php' ?> 
    <div class="container my-3">
    <div class="button-container">
        <a href="Leavest.php" class="button btn-primary">STUDENTS LEAVE</a>
        <a href="techleave.php" class="button btn-secondary">TEACHERS LEAVE</a>
        <a href="driverleave.php" class="button btn-danger">DRIVERS LEAVE</a>
    </div>
    <br/>
  <!--/banner-->
  <div class="banner-wthree-info container">
        <div class="row">
            <div class="col-lg-5 banner-left-info">
                
               
         
    </div>
</div>

<!-- //banner-->
 <table class="table table-striped table-dark">
  <thead>
    <tr>
     
      <th scope="col">  STUDENT ID</th>
      <!-- <th scope="col">  STUDENT NAME</th> -->
      <th scope="col">  REASON FOR LEAVE</th>
      <th scope="col">  FROM DATE</th>
      <th scope="col">  TO DATE</th>
      <th scope="col">  Leave Status</th>
      
    </tr>
  </thead>
    <?php
     $id="";
     include('dbconnect.php');
		


    
 
     $result = mysqli_query($conn,"SELECT * FROM studentleav  " )or die(mysqli_error());
     while($row = mysqli_fetch_array( $result ))
     {
       echo "<tr align='center'>";
       
      
       
       echo '<td><b><font color="white">' . $row['s_id'] . '</font></b></td>';
      
       // echo '<td><b><font color="white">' . $row['s_name'] . '</font></b></td>';
       echo '<td><b><font color="white">' . $row['reason'] . '</font></b></td>';
       echo '<td><b><font color="white">' . $row['from'] . '</font></b></td>';
       echo '<td><b><font color="white">' . $row['to'] . '</font></b></td>';
       echo '<td><div class="small-output-box">' . $row['status'] . '</div></td>';
       echo'<td> <a href="edit1.php?id='. $row['le_id'] . '" ><button type="Submit" >Approve</button></a></td>';
       echo'<td> <a href="edit.php?id='. $row['le_id'] . '" ><button type="Submit" >Reject</button></a></td>';
       echo'<td> <a href="delete.php?id=' . $row['le_id'] . '" ><button type="Submit" style="background-color:red; color:white;">Delete</button></a></td>';
      
   

       echo "</tr>";
                            }
                        
                            ?>        
                                                        
                                                    </tbody>
                                                    
                                                </table> 

   
   <p></p>
    
     
   



       
    <!-- js -->
 
    
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.3/dist/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
</body>
</html>