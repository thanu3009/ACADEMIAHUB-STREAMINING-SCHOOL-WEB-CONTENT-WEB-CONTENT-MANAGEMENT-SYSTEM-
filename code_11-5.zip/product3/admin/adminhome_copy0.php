<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.css">
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.0/jquery.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.min.js"></script>
    <title>Welcome - <?php $_SESSION['username']?></title>

  </head>
  <body>
    <?php require 'navhome.php' ?>
    
    <div class="container my-3">
    <div class="alert alert-success" role="alert">
      <h4 class="alert-heading">Welcome - Admin </h4>
      <hr>
      <p class="mb-0">Whenever you need to, be sure to logout <a href="/logout.php"> using this link.</a></p>
    </div>
    <br/>
  <!--/banner-->
  <div class="banner-wthree-info container">
        <div class="row">
            <div class="col-lg-5 banner-left-info">
                
               
         
    </div>
</div>

<!-- //banner-->
<div class="">
      <P></P>
      <form class="example" method="post" style="margin:auto;max-width:300px">
          <input type="number" placeholder="Enter Student ID" id="search1" name="search1">
          
<input type="submit" name="submit">
       
        </form>
   
    </div>
    <p></p>
    <table class="table table-striped table-dark">
  <thead>
    <tr>
     
      <th scope="col">  STUDENT ID</th>
      <th scope="col">  STUDENT NAME</th>
      <th scope="col">  BUS ID</th>
      <th scope="col">  LOCATION</th>
      <th scope="col">  BUS ENTER TIME</th>
      <th scope="col">  BUS EXIT TIME</th>
    </tr>
  </thead>
    <?php
     $id="";
     include('dbconnect.php');
		


    // session_start();
    //  $id=$_SESSION['username'];
    //  $result = mysqli_query($conn,"SELECT * FROM student_activity where s_id='".$id."' " )or die(mysqli_error());
    if (isset($_POST["submit"])) {
        $id = $_POST["search1"];
     $result = mysqli_query($conn,"SELECT * FROM student_activity where s_id='".$id."' " )or die(mysqli_error());
     while($row = mysqli_fetch_array( $result ))
     {
       echo "<tr align='center'>";
       
      
       
       echo '<td><b><font color="white">' . $row['s_id'] . '</font></b></td>';
      
       echo '<td><b><font color="white">' . $row['s_name'] . '</font></b></td>';
       echo '<td><b><font color="white">' . $row['b_id'] . '</font></b></td>';
       echo '<td><b><font color="white">' . $row['location'] . '</font></b></td>';
       echo '<td><b><font color="white">' . $row['entry_time'] . '</font></b></td>';
       echo '<td><b><font color="white">' . $row['exit_time'] . '</font></b></td>';
   

       echo "</tr>";
                            }
                        }
                            ?>        
                                                        
                                                    </tbody>
                                                    
                                                </table> 

   
   <p></p>
    
     
   



       
    <!-- js -->
 
    
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.3/dist/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
</body>
</html>