<?php
$server = "localhost";
$username = "root";
$password = "";
$database = "TJ_Schools";

$conn = mysqli_connect($server, $username, $password, $database);


?>
