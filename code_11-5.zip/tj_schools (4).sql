-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 11, 2025 at 04:23 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tj_schools`
--

-- --------------------------------------------------------

--
-- Table structure for table `attednce`
--

CREATE TABLE `attednce` (
  `s_id` int(11) NOT NULL,
  `S_name` varchar(20) NOT NULL,
  `cls_name` varchar(20) NOT NULL,
  `cls_id` varchar(20) NOT NULL,
  `no_of_cls_taken` int(11) NOT NULL,
  `no_of_cls_attend` int(100) DEFAULT NULL,
  `class_year` varchar(20) NOT NULL DEFAULT '2024-25',
  `missed_cls` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `attednce`
--

INSERT INTO `attednce` (`s_id`, `S_name`, `cls_name`, `cls_id`, `no_of_cls_taken`, `no_of_cls_attend`, `class_year`, `missed_cls`) VALUES
(7001, 'Nandini K', 'LKG', 'c101', 180, 170, '2024-25', '10'),
(7002, 'Rakshitha S', 'LKG', 'c101', 180, 160, '2024-25', '20'),
(7003, 'Siddhant Patil', 'LKG', 'c101', 180, 179, '2024-25', '1'),
(7004, 'Vaishnavi N', 'LKG', 'c101', 180, 175, '2024-25', '5'),
(7005, 'Apsara T', 'LKG', 'c101', 180, 163, '2024-25', '17'),
(6001, 'Navin N', 'UKG', 'c102', 180, 165, '2024-25', '15'),
(6002, 'Raksha R', 'UKG', 'c102', 180, 155, '2024-25', '25'),
(6003, 'Amulya k', 'UKG', 'c102', 180, 177, '2024-25', '3'),
(6004, 'Keerthana M', 'UKG', 'c102', 180, 179, '2024-25', '1'),
(6005, 'Ranjitha J', 'UKG', 'c102', 180, 172, '2024-25', '8'),
(5001, 'Mahananda M', '1ST-CLASS', 'c103', 250, 249, '2024-25', '1'),
(5002, 'Spoorthi L', '1ST-CLASS', 'c103', 250, 230, '2024-25', '20'),
(5003, 'Thrishika M', '1ST-CLASS', 'c103', 250, 246, '2024-25', '4'),
(5004, 'Teja P', '1ST-CLASS', 'c103', 250, 226, '2024-25', '24'),
(5005, 'Amrutha P', '1ST-CLASS', 'c103', 250, 238, '2024-25', '12'),
(4001, 'Pranathi M', '2ND-CLASS', 'c104', 250, 249, '2024-25', '1'),
(4002, 'Arthi N', '2ND-CLASS', 'c104', 250, 234, '2024-25', '16'),
(4003, 'Michu L', '2ND-CLASS', 'c104', 250, 245, '2024-25', '5'),
(4004, 'Basava S', '2ND-CLASS', 'c104', 250, 235, '2024-25', '15'),
(4005, 'Basavarajandra c', '2ND-CLASS', 'c104', 250, 245, '2024-25', '5'),
(3001, 'Bhuvika S', '3RD-CLASS', 'c105', 250, 246, '2024-25', '4'),
(3002, 'Thanmy P', '3RD-CLASS', 'c105', 250, 245, '2024-25', '5'),
(3003, 'Puttananja B', '3RD-CLASS', 'c105', 250, 231, '2024-25', '19'),
(3004, 'Muktha G', '3RD-CLASS', 'c105', 250, 239, '2024-25', '11'),
(3005, 'Molya L', 'moly\'3RD-CLASS', 'c105', 250, 238, '2024-25', '12'),
(2001, 'Lakshmi M', '4TH-CLASS', 'c106', 250, 232, '2024-25', '18'),
(2002, 'Bhashkar S', '4TH-CLASS', 'c106', 250, 235, '2024-25', '15'),
(2003, 'Saraswathi C', '4TH-CLASS', 'c106', 250, 247, '2024-25', '3'),
(2004, 'Jothika V', '4TH-CLASS', 'c106', 250, 226, '2024-25', '24'),
(2005, 'Roshan A', '4TH-CLASS', 'c106', 250, 241, '2024-25', '9'),
(1002, 'Akkamahadevi L', '5TH-CLASS', 'c107', 260, 257, '2024-25', '3'),
(1003, 'Vishwash B', '5TH-CLASS', 'c107', 260, 251, '2024-25', '9'),
(1004, 'Gukesh Y', '5TH-CLASS', 'c107', 260, 245, '2024-25', '15'),
(1005, 'Nick Vujicic', '5TH-CLASS', 'c107', 260, 253, '2024-25', '9'),
(7001, 'Nandini K', 'LKG', 'c101', 180, 170, '2024-25', '10');

-- --------------------------------------------------------

--
-- Table structure for table `bus`
--

CREATE TABLE `bus` (
  `b_id` varchar(20) NOT NULL,
  `b_reg` varchar(20) NOT NULL,
  `route` varchar(100) NOT NULL,
  `c_driverid` varchar(100) NOT NULL,
  `d_name` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bus`
--

INSERT INTO `bus` (`b_id`, `b_reg`, `route`, `c_driverid`, `d_name`) VALUES
('BUS001', 'KA 09 TJ 2001', 'RMC', 'DR001', 'Ramesh Kumar'),
('BUS002', 'KA 09 TJ 2002', 'GUNHOUSE', 'DR002', 'Suresh Kumar'),
('BUS003', 'KA 09 TJ 2002', 'CHAMUDIPURAM', 'DR003', 'Nagesh Kumar');

-- --------------------------------------------------------

--
-- Table structure for table `cls`
--

CREATE TABLE `cls` (
  `c_id` varchar(20) NOT NULL,
  `c_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cls`
--

INSERT INTO `cls` (`c_id`, `c_name`) VALUES
('c101', 'LKG'),
('c102', 'UKG'),
('c103', '1st class'),
('c104', '2nd class'),
('c105', '3rd class'),
('c106', '4th class'),
('c107', '5th class'),
('c108', 'sports');

-- --------------------------------------------------------

--
-- Table structure for table `drileave`
--

CREATE TABLE `drileave` (
  `le_id` int(100) NOT NULL,
  `s_id` varchar(20) NOT NULL,
  `s_name` varchar(100) NOT NULL,
  `reason` varchar(100) NOT NULL,
  `from` varchar(100) NOT NULL,
  `to` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL DEFAULT 'Pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `driver`
--

CREATE TABLE `driver` (
  `d_id` varchar(20) NOT NULL,
  `d_name` varchar(20) NOT NULL,
  `route` varchar(100) NOT NULL,
  `dl` varchar(20) NOT NULL,
  `address` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `driver`
--

INSERT INTO `driver` (`d_id`, `d_name`, `route`, `dl`, `address`, `password`) VALUES
('DR001', 'Ramesh kumar', 'RMC', 'DL20221021', '#91,Near bus stop RMC,Mysore', 'rame'),
('DR002', 'Suresh Kumar', 'GunHouse', 'DL20221022', '#02,Near Railway station  Mysore', 'sure'),
('DR003', 'Nagesh Kumar', 'ChamundiPuram ', 'DL20221023', '#30,Near police station,ChamundiPuram  Mysore', 'nage'),
('DR004', 'Rohith Kumar', 'ChamundiPuram ', 'DL20221024', '#40,Near pPetrol Bunk,ChamundiPuram  Mysore', 'nage');

-- --------------------------------------------------------

--
-- Table structure for table `entry`
--

CREATE TABLE `entry` (
  `s_id` int(20) NOT NULL,
  `s_name` varchar(100) DEFAULT NULL,
  `b_id` int(20) NOT NULL,
  `location` varchar(100) NOT NULL,
  `entry_time` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `entry1`
--

CREATE TABLE `entry1` (
  `s_id` int(20) NOT NULL,
  `s_name` varchar(100) DEFAULT NULL,
  `b_id` int(20) NOT NULL,
  `location` varchar(100) NOT NULL,
  `entry_time` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `entry1`
--

INSERT INTO `entry1` (`s_id`, `s_name`, `b_id`, `location`, `entry_time`) VALUES
(1001, 'Mahananda', 123, 'technopark_phase_1', '2022-10-20 07:51:53'),
(1002, 'Siddhant', 124, 'chaka', '2022-10-20 07:52:53'),
(1003, 'Navin', 125, 'east_fort', '2022-10-20 07:55:53'),
(1004, 'Divya', 123, 'technopark_phase_1', '2022-10-20 07:52:53'),
(1001, 'Mahananda', 123, 'technopark_phase_1', '2022-10-22 07:51:53'),
(1002, 'Siddhant', 124, 'chaka', '2022-10-23 08:51:53');

-- --------------------------------------------------------

--
-- Table structure for table `exit11`
--

CREATE TABLE `exit11` (
  `s_id` int(20) NOT NULL,
  `s_name` varchar(100) DEFAULT NULL,
  `b_id` int(20) NOT NULL,
  `location` varchar(100) NOT NULL,
  `exit_time` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `exit11`
--

INSERT INTO `exit11` (`s_id`, `s_name`, `b_id`, `location`, `exit_time`) VALUES
(1001, 'Mahananda', 123, 'technopark_phase_1', '2022-10-20 08:51:53'),
(1002, 'Siddhant', 124, 'chaka', '2022-10-20 08:52:53'),
(1003, 'Navin', 125, 'east_fort', '2022-10-20 08:55:53'),
(1004, 'Divya', 123, 'stechnopark_phase_1sv', '2022-10-20 08:52:53'),
(1005, 'Saurabh', 124, 'chaka', '2022-10-20 08:53:53'),
(1006, 'Ritvika', 125, 'east_fort', '2022-10-20 08:56:53'),
(1007, 'Paranli', 123, 'technopark_phase_1', '2022-10-20 08:50:53'),
(1008, 'Prashanthi', 124, 'chaka', '2022-10-20 08:51:53'),
(1001, 'Mahananda', 123, 'technopark_phase_1', '2022-10-21 04:51:53'),
(1001, 'Mahananda', 123, 'technopark_phase_1', '2022-10-22 08:51:53'),
(1001, 'Mahananda', 123, 'technopark_phase_1', '2022-10-23 08:51:53'),
(1002, 'Siddhant', 124, 'chaka', '2022-10-21 09:51:53'),
(1002, 'Siddhant', 124, 'chaka', '2022-10-22 09:51:53'),
(1002, 'Siddhant', 124, 'chaka', '2022-10-23 09:51:53');

-- --------------------------------------------------------

--
-- Table structure for table `fee`
--

CREATE TABLE `fee` (
  `f_id` int(20) NOT NULL,
  `class` varchar(50) NOT NULL,
  `fee` varchar(100) NOT NULL,
  `add_open` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `fee`
--

INSERT INTO `fee` (`f_id`, `class`, `fee`, `add_open`) VALUES
(223, 'LKG', '20,000 RS', 2025),
(224, 'UKG', '30,000 RS', 2025),
(225, '1ST', '40,000 RS', 2025),
(226, '2ND', '50,000 RS', 2025),
(227, '3RD', '55,000 RS', 2025),
(228, '4TH', '60,000 RS', 2025),
(229, '5TH', '70,000 RS', 2025);

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `uid` int(255) NOT NULL,
  `comments` text NOT NULL,
  `reply` text DEFAULT NULL,
  `timestamp` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`id`, `name`, `uid`, `comments`, `reply`, `timestamp`) VALUES
(6, 'Akkamahadevi L', 1002, 'ERF', 'wedrftgyuiol', '2025-05-11 18:56:40');

-- --------------------------------------------------------

--
-- Table structure for table `function`
--

CREATE TABLE `function` (
  `f_id` int(20) NOT NULL,
  `fun_name` varchar(100) NOT NULL,
  `fun_locatin` varchar(100) NOT NULL,
  `fun_date` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `function`
--

INSERT INTO `function` (`f_id`, `fun_name`, `fun_locatin`, `fun_date`) VALUES
(123, '25th Anniversary', 'TJ_School Ground', '2025-04-10'),
(124, 'Independence-Day', 'TJ_School Ground', '2025-08-15'),
(125, 'Telent-Day', 'TJ_School ', '2025-08-30');

-- --------------------------------------------------------

--
-- Table structure for table `homework`
--

CREATE TABLE `homework` (
  `h_id` int(20) NOT NULL,
  `cls_id` varchar(20) NOT NULL,
  `sub_id` varchar(20) NOT NULL,
  `subject` varchar(100) NOT NULL,
  `t_id` int(20) NOT NULL,
  `topic` varchar(100) DEFAULT NULL,
  `due_date` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `homework`
--

INSERT INTO `homework` (`h_id`, `cls_id`, `sub_id`, `subject`, `t_id`, `topic`, `due_date`) VALUES
(421, 'c103', 'S101', 'Kannada', 555, 'Grammer', '2025-10-03'),
(422, 'c104', 'S102', 'English', 666, 'Grammer', '2025-10-03'),
(0, '555', '1st class', 'S101', 0, 'Grammer', '2025-10-03');

-- --------------------------------------------------------

--
-- Table structure for table `homework1`
--

CREATE TABLE `homework1` (
  `h_id` int(11) NOT NULL,
  `t_id` varchar(11) NOT NULL,
  `cls_id` varchar(20) NOT NULL,
  `cls_name` varchar(20) NOT NULL,
  `sub_id` varchar(20) NOT NULL,
  `subject` varchar(100) NOT NULL,
  `topic` varchar(100) DEFAULT NULL,
  `due_date` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL DEFAULT 'Pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `homework1`
--

INSERT INTO `homework1` (`h_id`, `t_id`, `cls_id`, `cls_name`, `sub_id`, `subject`, `topic`, `due_date`, `status`) VALUES
(446, 'Tech001', 'c107', '5th class', 'S101', 'Kannada', 'swdedwr', '2025-05-12', 'Pending');

-- --------------------------------------------------------

--
-- Table structure for table `markscard`
--

CREATE TABLE `markscard` (
  `s_id` int(11) NOT NULL,
  `S_name` varchar(20) NOT NULL,
  `cls_name` varchar(20) NOT NULL,
  `cls_id` varchar(20) NOT NULL,
  `sub_id` varchar(20) NOT NULL,
  `subject` varchar(100) NOT NULL,
  `max_marks` int(11) NOT NULL,
  `Marks` int(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `markscard`
--

INSERT INTO `markscard` (`s_id`, `S_name`, `cls_name`, `cls_id`, `sub_id`, `subject`, `max_marks`, `Marks`) VALUES
(7001, 'Nandini K', 'LKG', 'C101', 'S101', 'Kannada', 100, 70),
(7001, 'Nandini K', 'LKG', 'C101', 'S102', 'English', 100, 60),
(7001, 'Nandini K', 'LKG', 'C101', 'S103', 'Maths', 100, 50),
(7001, 'Nandini K', 'LKG', 'C101', 'S108', 'GK', 100, 91),
(7001, 'Nandini K', 'LKG', 'C101', 'S109', 'Rhymes', 100, 100),
(7001, 'Nandini K', 'LKG', 'C101', 'S107', 'Drawing', 100, 80),
(7002, 'Rakshitha S', 'LKG', 'C101', 'S101', 'Kannada', 100, 70),
(7002, 'Rakshitha S', 'LKG', 'C101', 'S102', 'English', 100, 60),
(7002, 'Rakshitha S', 'LKG', 'C101', 'S103', 'Maths', 100, 50),
(7002, 'Rakshitha S', 'LKG', 'C101', 'S108', 'GK', 100, 91),
(7002, 'Rakshitha S', 'LKG', 'C101', 'S109', 'Rhymes', 100, 100),
(7002, 'Rakshitha S', 'LKG', 'C101', 'S107', 'Drawing', 100, 80),
(7003, 'Siddhant Patil', 'LKG', 'C101', 'S101', 'Kannada', 100, 70),
(7003, 'Siddhant Patil', 'LKG', 'C101', 'S102', 'English', 100, 60),
(7003, 'Siddhant Patil', 'LKG', 'C101', 'S103', 'Maths', 100, 50),
(7003, 'Siddhant Patil', 'LKG', 'C101', 'S108', 'GK', 100, 91),
(7003, 'Siddhant Patil', 'LKG', 'C101', 'S109', 'Rhymes', 100, 100),
(7003, 'Siddhant Patil', 'LKG', 'C101', 'S107', 'Drawing', 100, 80),
(7004, 'Vaishnavi N', 'LKG', 'C101', 'S101', 'Kannada', 100, 70),
(7004, 'Vaishnavi N', 'LKG', 'C101', 'S102', 'English', 100, 60),
(7004, 'Vaishnavi N', 'LKG', 'C101', 'S103', 'Maths', 100, 50),
(7004, 'Vaishnavi N', 'LKG', 'C101', 'S108', 'GK', 100, 91),
(7004, 'Vaishnavi N', 'LKG', 'C101', 'S109', 'Rhymes', 100, 100),
(7004, 'Vaishnavi N', 'LKG', 'C101', 'S107', 'Drawing', 100, 80),
(7005, 'Apsara T', 'LKG', 'C101', 'S101', 'Kannada', 100, 70),
(7005, 'Apsara T', 'LKG', 'C101', 'S102', 'English', 100, 60),
(7005, 'Apsara T', 'LKG', 'C101', 'S103', 'Maths', 100, 50),
(7005, 'Apsara T', 'LKG', 'C101', 'S108', 'GK', 100, 91),
(7005, 'Apsara T', 'LKG', 'C101', 'S109', 'Rhymes', 100, 100),
(7005, 'Apsara T', 'LKG', 'C101', 'S107', 'Drawing', 100, 80),
(6001, 'Navin N', 'UKG', 'C101', 'S101', 'Kannada', 100, 70),
(6001, 'Navin N', 'UKG', 'C101', 'S102', 'English', 100, 60),
(6001, 'Navin N', 'UKG', 'C101', 'S103', 'Maths', 100, 50),
(6001, 'Navin N', 'UKG', 'C101', 'S108', 'GK', 100, 91),
(6001, 'Navin N', 'UKG', 'C101', 'S109', 'Rhymes', 100, 100),
(6001, 'Navin N', 'UKG', 'C101', 'S107', 'Drawing', 100, 80),
(6002, 'Raksha R', 'UKG', 'C101', 'S101', 'Kannada', 100, 70),
(6002, 'Raksha R', 'UKG', 'C101', 'S102', 'English', 100, 60),
(6002, 'Raksha R', 'UKG', 'C101', 'S103', 'Maths', 100, 50),
(6002, 'Raksha R', 'UKG', 'C101', 'S108', 'GK', 100, 91),
(6002, 'Raksha R', 'UKG', 'C101', 'S109', 'Rhymes', 100, 100),
(6002, 'Raksha R', 'UKG', 'C101', 'S107', 'Drawing', 100, 80),
(6003, 'Amulya K', 'UKG', 'C101', 'S101', 'Kannada', 100, 70),
(6003, 'Amulya K', 'UKG', 'C101', 'S102', 'English', 100, 60),
(6003, 'Amulya K', 'UKG', 'C101', 'S103', 'Maths', 100, 50),
(6003, 'Amulya K', 'UKG', 'C101', 'S108', 'GK', 100, 91),
(6003, 'Amulya K', 'UKG', 'C101', 'S109', 'Rhymes', 100, 100),
(6003, 'Amulya K', 'UKG', 'C101', 'S107', 'Drawing', 100, 80),
(6004, 'Keerthana M', 'UKG', 'C101', 'S101', 'Kannada', 100, 70),
(6004, 'Keerthana M', 'UKG', 'C101', 'S102', 'English', 100, 60),
(6004, 'Keerthana M', 'UKG', 'C101', 'S103', 'Maths', 100, 50),
(6004, 'Keerthana M', 'UKG', 'C101', 'S108', 'GK', 100, 91),
(6004, 'Keerthana M', 'UKG', 'C101', 'S109', 'Rhymes', 100, 100),
(6004, 'Keerthana M', 'UKG', 'C101', 'S107', 'Drawing', 100, 80),
(6005, 'Amrutha P', 'UKG', 'C101', 'S101', 'Kannada', 100, 70),
(6005, 'Amrutha P', 'UKG', 'C101', 'S102', 'English', 100, 60),
(6005, 'Amrutha P', 'UKG', 'C101', 'S103', 'Maths', 100, 50),
(6005, 'Amrutha P', 'UKG', 'C101', 'S108', 'GK', 100, 91),
(6005, 'Amrutha P', 'UKG', 'C101', 'S109', 'Rhymes', 100, 100),
(6005, 'Amrutha P', 'UKG', 'C101', 'S107', 'Drawing', 100, 80),
(5001, 'Mahananda M', '1ST-CLASS', 'c103', 'S101', 'Kannada', 100, 90),
(5001, 'Mahananda M', '1ST-CLASS', 'c103', 'S102', 'English', 100, 80),
(5001, 'Mahananda M', '1ST-CLASS', 'c103', 'S103', 'Maths', 100, 85),
(5001, 'Mahananda M', '1ST-CLASS', 'c103', 'S104', 'Science', 100, 90),
(5001, 'Mahananda M', '1ST-CLASS', 'c103', 'S105', 'Hindi', 100, 80),
(5001, 'Mahananda M', '1ST-CLASS', 'c103', 'S106', 'Scocial-Science', 100, 85),
(5001, 'Mahananda M', '1ST-CLASS', 'c103', 'S107', 'Sports', 50, 40),
(5002, 'Spoorthi L', '1ST-CLASS', 'c103', 'S101', 'Kannada', 100, 90),
(5002, 'Spoorthi L', '1ST-CLASS', 'c103', 'S102', 'English', 100, 80),
(5002, 'Spoorthi L', '1ST-CLASS', 'c103', 'S103', 'Maths', 100, 85),
(5002, 'Spoorthi L', '1ST-CLASS', 'c103', 'S104', 'Science', 100, 90),
(5002, 'Spoorthi L', '1ST-CLASS', 'c103', 'S105', 'Hindi', 100, 80),
(5002, 'Spoorthi L', '1ST-CLASS', 'c103', 'S106', 'Scocial-Science', 100, 85),
(5002, 'Spoorthi L', '1ST-CLASS', 'c103', 'S107', 'Sports', 50, 40),
(5003, 'Thrishika L', '1ST-CLASS', 'c103', 'S101', 'Kannada', 100, 90),
(5003, 'Thrishika L', '1ST-CLASS', 'c103', 'S102', 'English', 100, 80),
(5003, 'Thrishika L', '1ST-CLASS', 'c103', 'S103', 'Maths', 100, 85),
(5003, 'Thrishika L', '1ST-CLASS', 'c103', 'S104', 'Science', 100, 90),
(5003, 'Thrishika L', '1ST-CLASS', 'c103', 'S105', 'Hindi', 100, 80),
(5003, 'Thrishika L', '1ST-CLASS', 'c103', 'S106', 'Scocial-Science', 100, 85),
(5003, 'Thrishika L', '1ST-CLASS', 'c103', 'S107', 'Sports', 50, 40),
(5004, 'Teja P', '1ST-CLASS', 'c103', 'S101', 'Kannada', 100, 90),
(5004, 'Teja P', '1ST-CLASS', 'c103', 'S102', 'English', 100, 80),
(5004, 'Teja P', '1ST-CLASS', 'c103', 'S103', 'Maths', 100, 85),
(5004, 'Teja P', '1ST-CLASS', 'c103', 'S104', 'Science', 100, 90),
(5004, 'Teja P', '1ST-CLASS', 'c103', 'S105', 'Hindi', 100, 80),
(5004, 'Teja P', '1ST-CLASS', 'c103', 'S106', 'Scocial-Science', 100, 85),
(5004, 'Teja P', '1ST-CLASS', 'c103', 'S107', 'Sports', 50, 40),
(5005, 'Amrutha P', '1ST-CLASS', 'c103', 'S101', 'Kannada', 100, 90),
(5005, 'Amrutha P', '1ST-CLASS', 'c103', 'S102', 'English', 100, 80),
(5005, 'Amrutha P', '1ST-CLASS', 'c103', 'S103', 'Maths', 100, 85),
(5005, 'Amrutha P', '1ST-CLASS', 'c103', 'S104', 'Science', 100, 90),
(5005, 'Amrutha P', '1ST-CLASS', 'c103', 'S105', 'Hindi', 100, 80),
(5005, 'Amrutha P', '1ST-CLASS', 'c103', 'S106', 'Scocial-Science', 100, 85),
(5005, 'Amrutha P', '1ST-CLASS', 'c103', 'S107', 'Sports', 50, 40),
(4001, 'Pranathi M', '2ND-CLASS', 'c104', 'S101', 'Kannada', 100, 90),
(4001, 'Pranathi M', '2ND-CLASS', 'c104', 'S102', 'English', 100, 80),
(4001, 'Pranathi M', '2ND-CLASS', 'c104', 'S103', 'Maths', 100, 85),
(4001, 'Pranathi M', '2ND-CLASS', 'c104', 'S104', 'Science', 100, 90),
(4001, 'Pranathi M', '2ND-CLASS', 'c104', 'S105', 'Hindi', 100, 80),
(4001, 'Pranathi M', '2ND-CLASS', 'c104', 'S106', 'Scocial-Science', 100, 85),
(4001, 'Pranathi M', '2ND-CLASS', 'c104', 'S107', 'Sports', 50, 40),
(4002, 'Arthi N', '2ND-CLASS', 'c104', 'S101', 'Kannada', 100, 90),
(4002, 'Arthi N', '2ND-CLASS', 'c104', 'S102', 'English', 100, 80),
(4002, 'Arthi N', '2ND-CLASS', 'c104', 'S103', 'Maths', 100, 85),
(4002, 'Arthi N', '2ND-CLASS', 'c103', 'S104', 'Science', 100, 90),
(4002, 'Arthi N', '2ND-CLASS', 'c104', 'S105', 'Hindi', 100, 80),
(4002, 'Arthi N', '2ND-CLASS', 'c104', 'S106', 'Scocial-Science', 100, 85),
(4002, 'Arthi N', '2ND-CLASS', 'c104', 'S107', 'Sports', 50, 40),
(4003, 'Minchu L', '2ND-CLASS', 'c104', 'S101', 'Kannada', 100, 90),
(4003, 'Minchu L', '2ND-CLASS', 'c104', 'S102', 'English', 100, 80),
(4003, 'Minchu L', '2ND-CLASS', 'c104', 'S103', 'Maths', 100, 85),
(4003, 'Minchu L', '2ND-CLASS', 'c104', 'S104', 'Science', 100, 90),
(4003, 'Minchu L', '2ND-CLASS', 'c104', 'S105', 'Hindi', 100, 80),
(4003, 'Minchu L', '2ND-CLASS', 'c104', 'S106', 'Scocial-Science', 100, 85),
(4003, 'Minchu L', '2ND-CLASS', 'c104', 'S107', 'Sports', 50, 40),
(4004, 'Basava S', '2ND-CLASS', 'c104', 'S101', 'Kannada', 100, 90),
(4004, 'Basava S', '2ND-CLASS', 'c104', 'S102', 'English', 100, 80),
(4004, 'Basava S', '2ND-CLASS', 'c104', 'S103', 'Maths', 100, 85),
(4004, 'Basava S', '2ND-CLASS', 'c104', 'S104', 'Science', 100, 90),
(4004, 'Basava S', '2ND-CLASS', 'c104', 'S105', 'Hindi', 100, 80),
(4004, 'Basava S', '2ND-CLASS', 'c104', 'S106', 'Scocial-Science', 100, 85),
(4004, 'Basava S', '2ND-CLASS', 'c104', 'S107', 'Sports', 50, 40),
(4005, 'Basavarajandra C', '2ND-CLASS', 'c104', 'S101', 'Kannada', 100, 90),
(4005, 'Basavarajandra C', '2ND-CLASS', 'c104', 'S102', 'English', 100, 80),
(4005, 'Basavarajandra C', '2ND-CLASS', 'c104', 'S103', 'Maths', 100, 85),
(4005, 'Basavarajandra C', '2ND-CLASS', 'c104', 'S104', 'Science', 100, 90),
(4005, 'Basavarajandra C', '2ND-CLASS', 'c104', 'S105', 'Hindi', 100, 80),
(4005, 'Basavarajandra C', '2ND-CLASS', 'c104', 'S106', 'Scocial-Science', 100, 85),
(4005, 'Basavarajandra C', '2ND-CLASS', 'c104', 'S107', 'Sports', 50, 40),
(3001, 'Bhuvika S', '3RD_CLASS', 'c105', 'S101', 'Kannada', 100, 90),
(3001, 'Bhuvika S', '3RD-CLASS', 'c105', 'S102', 'English', 100, 80),
(3001, 'Bhuvika S', '3RD-CLASS', 'c105', 'S103', 'Maths', 100, 85),
(3001, 'Bhuvika S', '3RD-CLASS', 'c105', 'S104', 'Science', 100, 90),
(3001, 'Bhuvika S', '3RD-CLASS', 'c105', 'S105', 'Hindi', 100, 80),
(3001, 'Bhuvika S', '3RD-CLASS', 'c105', 'S106', 'Scocial-Science', 100, 85),
(3001, 'Bhuvika S', '3RD-CLASS', 'c105', 'S107', 'Sports', 50, 40),
(3002, 'Thanmy p', '3RD_CLASS', 'c105', 'S101', 'Kannada', 100, 90),
(3002, 'Thanmy P', '3RD-CLASS', 'c105', 'S102', 'English', 100, 80),
(3002, 'Thanmy P', '3RD-CLASS', 'c105', 'S103', 'Maths', 100, 85),
(3002, 'Thanmy P', '3RD-CLASS', 'c105', 'S103', 'Maths', 100, 85),
(3002, 'Thanmy P', '3RD-CLASS', 'c105', 'S104', 'Science', 100, 90),
(3002, 'Thanmy P', '3RD-CLASS', 'c105', 'S105', 'Hindi', 100, 80),
(3002, 'Thanmy P', '3RD-CLASS', 'c105', 'S106', 'Scocial-Science', 100, 85),
(3002, 'Thanmy P', '3RD-CLASS', 'c105', 'S107', 'Sports', 50, 40),
(3003, 'Puttananja B', '3RD_CLASS', 'c105', 'S101', 'Kannada', 100, 90),
(3003, 'Puttananja B', '3RD-CLASS', 'c105', 'S102', 'English', 100, 80),
(3003, 'Puttananja B', '3RD-CLASS', 'c105', 'S103', 'Maths', 100, 85),
(3003, 'Puttananja B', '3RD-CLASS', 'c105', 'S104', 'Science', 100, 90),
(3003, 'Puttananja B', '3RD-CLASS', 'c105', 'S105', 'Hindi', 100, 80),
(3003, 'Puttananja B', '3RD-CLASS', 'c105', 'S106', 'Scocial-Science', 100, 85),
(3003, 'Puttananja B', '3RD-CLASS', 'c105', 'S107', 'Sports', 50, 40),
(3004, 'Muktha G', '3RD_CLASS', 'c105', 'S101', 'Kannada', 100, 90),
(3004, 'Muktha G', '3RD-CLASS', 'c105', 'S102', 'English', 100, 80),
(3004, 'Muktha G', '3RD-CLASS', 'c105', 'S103', 'Maths', 100, 85),
(3004, 'Muktha G', '3RD-CLASS', 'c105', 'S104', 'Science', 100, 90),
(3004, 'Muktha G', '3RD-CLASS', 'c105', 'S105', 'Hindi', 100, 80),
(3004, 'Muktha G', '3RD-CLASS', 'c105', 'S106', 'Scocial-Science', 100, 85),
(3004, 'Muktha G', '3RD-CLASS', 'c105', 'S107', 'Sports', 50, 40),
(3005, 'Moulya L', '3RD_CLASS', 'c105', 'S101', 'Kannada', 100, 90),
(3005, 'Moulya L', '3RD-CLASS', 'c105', 'S102', 'English', 100, 80),
(3005, 'Moulya L', '3RD-CLASS', 'c105', 'S103', 'Maths', 100, 85),
(3005, 'Moulya L', '3RD-CLASS', 'c105', 'S104', 'Science', 100, 90),
(3005, 'Moulya L', '3RD-CLASS', 'c105', 'S105', 'Hindi', 100, 80),
(3005, 'Moulya L', '3RD-CLASS', 'c105', 'S106', 'Scocial-Science', 100, 85),
(3005, 'Moulya L', '3RD-CLASS', 'c105', 'S107', 'Sports', 50, 40),
(2001, 'Lakshmi M', '4TH_CLASS', 'c106', 'S101', 'Kannada', 100, 90),
(2001, 'Lakshmi M', '4TH-CLASS', 'c106', 'S102', 'English', 100, 80),
(2001, 'Lakshmi M', '4TH-CLASS', 'c106', 'S103', 'Maths', 100, 85),
(2001, 'Lakshmi M', '4TH-CLASS', 'c106', 'S104', 'Science', 100, 90),
(2001, 'Lakshmi M', '4TH-CLASS', 'c106', 'S105', 'Hindi', 100, 80),
(2001, 'Lakshmi M', '4TH-CLASS', 'c106', 'S106', 'Scocial-Science', 100, 85),
(2001, 'Lakshmi M', '4TH-CLASS', 'c106', 'S107', 'Sports', 50, 40),
(2002, 'Bhashkar S', '4TH_CLASS', 'c106', 'S101', 'Kannada', 100, 90),
(2002, 'Bhashkar S', '4TH-CLASS', 'c106', 'S102', 'English', 100, 80),
(2002, 'Bhashkar S', '4TH-CLASS', 'c106', 'S103', 'Maths', 100, 85),
(2002, 'Bhashkar S', '4TH-CLASS', 'c106', 'S104', 'Science', 100, 90),
(2002, 'Bhashkar S', '4TH-CLASS', 'c106', 'S105', 'Hindi', 100, 80),
(2002, 'Bhashkar S', '4TH-CLASS', 'c106', 'S106', 'Scocial-Science', 100, 85),
(2002, 'Bhashkar S', '4TH-CLASS', 'c106', 'S107', 'Sports', 50, 40),
(2003, 'Saraswathi C', '4TH_CLASS', 'c106', 'S101', 'Kannada', 100, 90),
(2003, 'Saraswathi C', '4TH-CLASS', 'c106', 'S102', 'English', 100, 80),
(2003, 'Saraswathi C', '4TH-CLASS', 'c106', 'S103', 'Maths', 100, 85),
(2003, 'Saraswathi C', '4TH-CLASS', 'c106', 'S104', 'Science', 100, 90),
(2003, 'Saraswathi C', '4TH-CLASS', 'c106', 'S105', 'Hindi', 100, 80),
(2003, 'Saraswathi C', '4TH-CLASS', 'c106', 'S106', 'Scocial-Science', 100, 85),
(2003, 'Saraswathi C', '4TH-CLASS', 'c106', 'S107', 'Sports', 50, 40),
(2004, 'Jothika V', '4TH_CLASS', 'c106', 'S101', 'Kannada', 100, 90),
(2004, 'Jothika V', '4TH_CLASS', 'c106', 'S101', 'Kannada', 100, 90),
(2004, 'Jothika V', '4TH-CLASS', 'c106', 'S102', 'English', 100, 80),
(2004, 'Jothika V', '4TH-CLASS', 'c106', 'S103', 'Maths', 100, 85),
(2004, 'Jothika V', '4TH-CLASS', 'c106', 'S104', 'Science', 100, 90),
(2004, 'Jothika V', '4TH-CLASS', 'c106', 'S105', 'Hindi', 100, 80),
(2004, 'Jothika V', '4TH-CLASS', 'c106', 'S106', 'Scocial-Science', 100, 85),
(2004, 'Jothika V', '4TH-CLASS', 'c106', 'S107', 'Sports', 50, 40),
(2005, 'Roshan A', '4TH_CLASS', 'c106', 'S101', 'Kannada', 100, 90),
(2005, 'Roshan A', '4TH-CLASS', 'c106', 'S102', 'English', 100, 80),
(2005, 'Roshan A', '4TH-CLASS', 'c106', 'S103', 'Maths', 100, 85),
(2005, 'Roshan A', '4TH-CLASS', 'c106', 'S104', 'Science', 100, 90),
(2005, 'Roshan A', '4TH-CLASS', 'c106', 'S105', 'Hindi', 100, 80),
(2005, 'Roshan A', '4TH-CLASS', 'c106', 'S106', 'Scocial-Science', 100, 85),
(2005, 'Roshan A', '4TH-CLASS', 'c106', 'S107', 'Sports', 50, 40),
(1001, 'Thanu S', '5TH_CLASS', 'c107', 'S101', 'Kannada', 100, 90),
(1001, 'Thanu S', '5TH-CLASS', 'c107', 'S102', 'English', 100, 80),
(1001, 'Thanu S', '5TH-CLASS', 'c107', 'S103', 'Maths', 100, 85),
(1001, 'Thanu S', '5TH-CLASS', 'c107', 'S104', 'Science', 100, 90),
(1001, 'Thanu S', '5TH-CLASS', 'c107', 'S105', 'Hindi', 100, 80),
(1001, 'Thanu S', '5TH-CLASS', 'c107', 'S106', 'Scocial-Science', 100, 85),
(1001, 'Thanu S', '5TH-CLASS', 'c107', 'S107', 'Sports', 50, 40),
(1002, 'Akkamahadevi L', '5TH_CLASS', 'c107', 'S101', 'Kannada', 100, 90),
(1002, 'Akkamahadevi L', '5TH-CLASS', 'c107', 'S102', 'English', 100, 80),
(1002, 'Akkamahadevi L', '5TH-CLASS', 'c107', 'S103', 'Maths', 100, 85),
(1002, 'Akkamahadevi L', '5TH-CLASS', 'c107', 'S104', 'Science', 100, 90),
(1002, 'Akkamahadevi L', '5TH-CLASS', 'c107', 'S105', 'Hindi', 100, 80),
(1002, 'Akkamahadevi L', '5TH-CLASS', 'c107', 'S106', 'Scocial-Science', 100, 85),
(1002, 'Akkamahadevi L', '5TH-CLASS', 'c107', 'S107', 'Sports', 50, 40),
(1003, 'Vishwash B', '5TH_CLASS', 'c107', 'S101', 'Kannada', 100, 90),
(1003, 'Vishwash B', '5TH-CLASS', 'c107', 'S102', 'English', 100, 80),
(1003, 'Vishwash B', '5TH-CLASS', 'c107', 'S103', 'Maths', 100, 85),
(1003, 'Vishwash B', '5TH-CLASS', 'c107', 'S104', 'Science', 100, 90),
(1003, 'Vishwash B', '5TH-CLASS', 'c107', 'S105', 'Hindi', 100, 80),
(1003, 'Vishwash B', '5TH-CLASS', 'c107', 'S106', 'Scocial-Science', 100, 85),
(1003, 'Vishwash B', '5TH-CLASS', 'c107', 'S107', 'Sports', 50, 40),
(1004, 'Gukesh V', '5TH_CLASS', 'c107', 'S101', 'Kannada', 100, 90),
(1004, 'Gukesh V', '5TH-CLASS', 'c107', 'S102', 'English', 100, 80),
(1004, 'Gukesh V', '5TH-CLASS', 'c107', 'S103', 'Maths', 100, 85),
(1004, 'Gukesh V', '5TH-CLASS', 'c107', 'S104', 'Science', 100, 90),
(1004, 'Gukesh V', '5TH-CLASS', 'c107', 'S105', 'Hindi', 100, 80),
(1004, 'Gukesh V', '5TH-CLASS', 'c107', 'S106', 'Scocial-Science', 100, 85),
(1004, 'GukeSH V', '5TH-CLASS', 'c107', 'S107', 'Sports', 50, 40),
(1005, 'Nick Vujicic', '5TH_CLASS', 'c107', 'S101', 'Kannada', 100, 90),
(1005, 'Nick Vujicic', '5TH-CLASS', 'c107', 'S102', 'English', 100, 80),
(1005, 'Nick Vujicic', '5TH-CLASS', 'c107', 'S103', 'Maths', 100, 85),
(1005, 'Nick Vujicic', '5TH-CLASS', 'c107', 'S104', 'Science', 100, 90),
(1005, 'Nick Vujicic', '5TH-CLASS', 'c107', 'S105', 'Hindi', 100, 80),
(1005, 'Nick Vujicic', '5TH-CLASS', 'c107', 'S106', 'Scocial-Science', 100, 85),
(1005, 'Nick vujicic', '5TH-CLASS', 'c107', 'S107', 'Sports', 50, 40);

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `id` int(11) NOT NULL,
  `sender` varchar(255) DEFAULT NULL,
  `receiver` varchar(255) DEFAULT NULL,
  `message` text DEFAULT NULL,
  `timestamp` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`id`, `sender`, `receiver`, `message`, `timestamp`) VALUES
(1, 'user', 'admin', 'd', '2025-04-12 19:40:44'),
(2, 'user', 'admin', 'dswdec', '2025-04-12 19:40:50');

-- --------------------------------------------------------

--
-- Table structure for table `pdf_files`
--

CREATE TABLE `pdf_files` (
  `id` int(11) NOT NULL,
  `cls_id` varchar(20) NOT NULL,
  `cls_name` varchar(20) NOT NULL,
  `sub_id` varchar(20) NOT NULL,
  `subject` varchar(100) NOT NULL,
  `t_id` varchar(20) NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `file_path` varchar(255) NOT NULL,
  `uploaded_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pdf_files`
--

INSERT INTO `pdf_files` (`id`, `cls_id`, `cls_name`, `sub_id`, `subject`, `t_id`, `file_name`, `file_path`, `uploaded_at`) VALUES
(14, 'c107', '5th class', 'S101', 'Kannada', 'Tech001', 'Section-3-Intro.pdf', 'uploads/Section-3-Intro.pdf', '2025-05-11 13:38:44'),
(15, 'c107', '5th class', 'S101', 'Kannada', 'Tech001', 'ExploringSQLServerConfigurationManager.pdf', 'uploads/ExploringSQLServerConfigurationManager.pdf', '2025-05-11 13:40:30');

-- --------------------------------------------------------

--
-- Table structure for table `schools`
--

CREATE TABLE `schools` (
  `s_id` varchar(20) NOT NULL,
  `s_name` varchar(20) NOT NULL,
  `licence_no` varchar(100) NOT NULL,
  `current_chairman` varchar(20) NOT NULL,
  `s_address` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `schools`
--

INSERT INTO `schools` (`s_id`, `s_name`, `licence_no`, `current_chairman`, `s_address`) VALUES
('S_001', 'MN_SCHOOLS', 'LC-KA2025001', 'Prudhvi Raj', '#001, Near Yale thota bus stop, Mysore');

-- --------------------------------------------------------

--
-- Table structure for table `sports`
--

CREATE TABLE `sports` (
  `s_id` int(20) NOT NULL,
  `s_name` varchar(50) NOT NULL,
  `next_pra` varchar(100) NOT NULL,
  `sports_date` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sports`
--

INSERT INTO `sports` (`s_id`, `s_name`, `next_pra`, `sports_date`) VALUES
(323, 'football', '2025-05-01', 2025),
(324, 'Cricket', '2025-05-01', 2025),
(325, 'Volleyball', '2025-05-01', 2025),
(326, 'Baseball', '2025-05-01', 2025);

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `s_id` int(20) NOT NULL,
  `s_name` varchar(100) NOT NULL,
  `Stoplocation` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `class` varchar(100) NOT NULL,
  `c_id` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`s_id`, `s_name`, `Stoplocation`, `address`, `password`, `class`, `c_id`) VALUES
(1001, 'Thanu S', 'RMC', '#102, Near Cell BANK, MYSORE', 'than', '5TH CLASS', 'c107'),
(1002, 'Akkamahadevi L', 'YALE-THOTA', '#901, Near JSS COLLEGE , MYSORE', 'akka', '5TH-CLASS', 'c107'),
(1003, 'Vishwash B', 'CHAMUDIPURAM', '#762,NEAR HOSPITAL,MYSORE', 'vish', '5TH-CLASS', 'c107'),
(1004, 'Gukesh Y', 'GUN-HOUSE', '#201, Near temple, MYSORE', 'guke', '5TH-CLASS', 'c107'),
(1005, 'Nick Vujicic', 'GUN-HOUSE', '#201, Near school, MYSORE', 'nick', '5TH-CLASS', 'c107'),
(2001, 'Lakshmi M', 'GUN-HOUSE', '#201, Near temple, MYSORE', 'laks', '4TH-CLASS', 'c106'),
(2002, 'Bhashkar S', 'GUN-HOUSE', '#201, Near temple, MYSORE', 'bhas', '4TH-CLASS', 'c106'),
(2003, 'Saraswathi C', 'RMC', '#101, Near HP BANK, MYSORE', 'sara', '4TH-CLASS', 'c106'),
(2004, 'Jothika V', 'CHAMUDIPURAM', '#762,NEAR HOSPITAL,MYSORE', 'joth', '4TH-CLASS', 'c106'),
(2005, 'Roshan A', 'YALE-THOTA', '#901, Near JSS COLLEGE , MYSORE', 'rosh', '4TH-CLASS', 'c106'),
(3001, 'Bhuvika S', 'YALE-THOTA', '#901, Near JSS COLLEGE , MYSORE', 'bhuv', '3RD-CLASS', 'c105'),
(3002, 'Thanmy P', 'CHAMUDIPURAM', '#762,NEAR HOSPITAL,MYSORE', 'than', '3RD-CLASS', 'c105'),
(3003, 'Puttananja B', 'RMC', '#101, Near HP BANK, MYSORE', 'putt', '3RD-CLASS', 'c105'),
(3004, 'Muktha G', 'RMC', '#101, Near HP BANK, MYSORE', 'mukt', '3RD-CLASS', 'c105'),
(3005, 'Molya L', 'GUN-HOUSE', '#201, Near temple, MYSORE', 'moly', '3RD-CLASS', 'c105'),
(4001, 'Pranathi M', 'CHAMUDIPURAM', '#762,NEAR HOSPITAL,MYSORE', 'pran', '2ND-CLASS', 'c104'),
(4002, 'Arthi N', 'GUN-HOUSE', '#201, Near temple, MYSORE', 'arth', '2ND-CLASS', 'c104'),
(4003, 'Michu L', 'YALE-THOTA', '#901, Near JSS COLLEGE , MYSORE', 'mich', '2ND-CLASS', 'c104'),
(4004, 'Basava S', 'RMC', '#101, Near HP BANK, MYSORE', 'basa', '2ND-CLASS', 'c104'),
(4005, 'Basavarajandra c', 'YALE-THOTA', '#901, Near JSS COLLEGE , MYSORE', 'basa', '2ND-CLASS', 'c104'),
(5001, 'Mahananda M', 'GUN-HOUSE', '#601, Near temple, MYSORE', 'maha', '1ST-CLASS', 'c103'),
(5002, 'Spoorthi L', 'YALE-THOTA', '#801, Near JSS COLLEGE , MYSORE', 'spoo', '1ST-CLASS', 'c103'),
(5003, 'Thrishika M', 'RMC', '#701, Near HP BANK, MYSORE', 'thri', '1ST-CLASS', 'c103'),
(5004, 'Teja P', 'GUN-HOUSE', '#201, Near temple, MYSORE', 'teja', '1ST-CLASS', 'c103'),
(5005, 'Amrutha P', 'CHAMUDIPURAM', '#762,NEAR HOSPITAL,MYSORE', 'amru', '1ST-CLASS', 'c103'),
(6001, 'Navin N', 'YALE-THOTA', '#801, Near JSS COLLEGE , MYSORE', 'navi', 'UKG', 'c102'),
(6002, 'Raksha R', 'GUN-HOUSE', '#601, Near temple, MYSORE', 'raks', 'UKG', 'C102'),
(6003, 'Amulya k', 'RMC', '#701, Near HP BANK, MYSORE', 'amul', 'UKG', 'C102'),
(6004, 'Keerthana M', 'GUNDURAVNAGARA', '#243,NEAR SCHOOL,MYSORE', 'keer', 'UKG', 'C102'),
(6005, 'Ranjitha J', 'CHAMUDIPURAM', '#762,NEAR HOSPITAL,MYSORE', 'ranj', 'UKG', 'C102'),
(7001, 'Nandini K', 'GUN-HOUSE', '#601, Near temple, MYSORE', 'nand', 'LKG', 'c101'),
(7002, 'Rakshitha S', 'YALE-THOTA', '#801, Near JSS COLLEGE , MYSORE', 'raks', 'LKG', 'c1001'),
(7003, 'Siddhant Patil', 'RMC', '#701, Near HP BANK, MYSORE', 'sidd', 'LKG', 'c101'),
(7004, 'Vaishnavi N', 'GUNDURAVNAGARA', '#243,NEAR SCHOOL,MYSORE', 'vais', 'LKG', 'C101'),
(7005, 'Apsara T', 'CHAMUDIPURAM', '#762,NEAR HOSPITAL,MYSORE', 'apsa', 'LKG', 'C101');

-- --------------------------------------------------------

--
-- Table structure for table `studentleav`
--

CREATE TABLE `studentleav` (
  `le_id` int(100) NOT NULL,
  `s_id` int(20) NOT NULL,
  `s_name` varchar(100) NOT NULL,
  `sp` varchar(100) DEFAULT NULL,
  `reason` varchar(100) NOT NULL,
  `from` varchar(100) NOT NULL,
  `to` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `studentleav`
--

INSERT INTO `studentleav` (`le_id`, `s_id`, `s_name`, `sp`, `reason`, `from`, `to`, `status`) VALUES
(209, 1001, 'Thanu S', 'RMC', 'wedfrge', '2025-04-12', '2025-04-24', 'Pending'),
(210, 1001, 'Thanu S', 'RMC', 'rr', '2025-04-12', '2025-04-25', 'Pending'),
(212, 1002, 'Akkamahadevi L', 'YALE-THOTA', 'ASCDV', '2025-05-23', '2025-05-24', 'Pending'),
(213, 1002, 'Akkamahadevi L', 'YALE-THOTA', '3ERF', '2025-05-21', '2025-05-22', 'Pending');

-- --------------------------------------------------------

--
-- Table structure for table `sub`
--

CREATE TABLE `sub` (
  `sub_id` varchar(20) NOT NULL,
  `sub_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sub`
--

INSERT INTO `sub` (`sub_id`, `sub_name`) VALUES
('S101', 'Kannada'),
('S102', 'English'),
('S103', 'Maths'),
('S104', 'Science'),
('S105', 'Hindi'),
('S106', 'Scocial-Science'),
('S107', 'Sports');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_employee`
--

CREATE TABLE `tbl_employee` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `address` text NOT NULL,
  `gender` varchar(10) NOT NULL,
  `designation` varchar(100) NOT NULL,
  `age` int(11) NOT NULL,
  `image` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tbl_employee`
--

INSERT INTO `tbl_employee` (`id`, `name`, `address`, `gender`, `designation`, `age`, `image`) VALUES
(1, 'Bruce Tom', '656 Edsel Road\r\nSherman Oaks, CA 91403', 'Male', 'Driver', 36, '1.jpg'),
(5, 'Clara Gilliam', '63 Woodridge Lane\r\nMemphis, TN 38138', 'Female', 'Programmer', 24, '2.jpg'),
(6, 'Barbra K. Hurley', '1241 Canis Heights Drive\r\nLos Angeles, CA 90017', 'Female', 'Service technician', 26, '3.jpg'),
(7, 'Antonio J. Forbes', '403 Snyder Avenue\r\nCharlotte, NC 28208', 'Male', 'Faller', 32, '4.jpg'),
(8, 'Charles D. Horst', '1636 Walnut Hill Drive\r\nCincinnati, OH 45202', 'Male', 'Financial investigator', 29, '5.jpg'),
(175, 'Ronald D. Colella', '1571 Bingamon Branch Road, Barrington, IL 60010', 'Male', 'Top executive', 32, '6.jpg'),
(174, 'Martha B. Tomlinson', '4005 Bird Spring Lane, Houston, TX 77002', 'Female', 'Systems programmer', 38, '7.jpg'),
(161, 'Glenda J. Stewart', '3482 Pursglove Court, Rossburg, OH 45362', 'Female', 'Cost consultant', 28, '8.jpg'),
(162, 'Jarrod D. Jones', '3827 Bingamon Road, Garfield Heights, OH 44125', 'Male', 'Manpower development advisor', 64, '9.jpg'),
(163, 'William C. Wright', '2653 Pyramid Valley Road, Cedar Rapids, IA 52404', 'Male', 'Political geographer', 33, '10.jpg'),
(178, 'Sara K. Ebert', '1197 Nelm Street\r\nMc Lean, VA 22102', 'Female', 'Billing machine operator', 50, ''),
(177, 'Patricia L. Scott', '1584 Dennison Street\r\nModesto, CA 95354', 'Female', 'Urban and regional planner', 54, ''),
(179, 'James K. Ridgway', '3462 Jody Road\r\nWayne, PA 19088', 'Female', 'Recreation leader', 41, ''),
(180, 'Stephen A. Crook', '448 Deercove Drive\r\nDallas, TX 75201', 'Male', 'Optical goods worker', 36, ''),
(181, 'Kimberly J. Ellis', '4905 Holt Street\r\nFort Lauderdale, FL 33301', 'Male', 'Dressing room attendant', 24, ''),
(182, 'Elizabeth N. Bradley', '1399 Randall Drive\r\nHonolulu, HI 96819', 'Female', ' Software quality assurance analyst', 25, ''),
(183, 'Steve John', '108, Vile Parle, CL', 'Male', 'Software Engineer', 29, ''),
(184, 'Marks Johnson', '021, Big street, NY', 'Male', 'Head of IT', 41, ''),
(185, 'Mak Pub', '1462 Juniper Drive\r\nBreckenridge, MI 48612', 'Male', 'Mental health counselor', 40, '');

-- --------------------------------------------------------

--
-- Table structure for table `teacher`
--

CREATE TABLE `teacher` (
  `t_id` varchar(100) NOT NULL,
  `t_name` varchar(100) NOT NULL,
  `subject` varchar(100) NOT NULL,
  `qulification` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `teacher`
--

INSERT INTO `teacher` (`t_id`, `t_name`, `subject`, `qulification`, `password`) VALUES
('Tech001', 'Apsara Murthi', 'Kannada', 'MA, B.Ed', 'apsa'),
('Tech002', 'Ram-Prasad', 'English', 'MA, B.Ed', 'ramu'),
('Tech003', 'Raghu Ram', 'Maths', 'MSC, B.Ed', 'ragh'),
('Tech004', 'Bheeshma R K', 'Science', 'MSC, B.Ed', 'bhee'),
('Tech005', 'Ravichnadra M', 'Scocial Science', 'MA, B.Ed', 'ravi'),
('Tech006', 'Sumathi Rao', 'Hindi', 'MA, B.Ed', 'suma'),
('Tech007', 'Kiran Murthi', 'Computer Science', 'MCA, B.Ed', 'apsa');

-- --------------------------------------------------------

--
-- Table structure for table `techleave`
--

CREATE TABLE `techleave` (
  `le_id` int(100) NOT NULL,
  `s_id` varchar(20) NOT NULL,
  `s_name` varchar(100) NOT NULL,
  `reason` varchar(100) NOT NULL,
  `from` varchar(100) NOT NULL,
  `to` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL DEFAULT 'Pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `techleave`
--

INSERT INTO `techleave` (`le_id`, `s_id`, `s_name`, `reason`, `from`, `to`, `status`) VALUES
(205, 'Tech001', 'Apsara Murthi', 'swdfvg', '2025-04-24', '2025-04-17', 'Pending');

-- --------------------------------------------------------

--
-- Table structure for table `tec_sub`
--

CREATE TABLE `tec_sub` (
  `t_id` varchar(20) NOT NULL,
  `sub_id` varchar(20) NOT NULL,
  `sub_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tec_sub`
--

INSERT INTO `tec_sub` (`t_id`, `sub_id`, `sub_name`) VALUES
('Tech001', 'S101', 'Kannada'),
('Tech005', 'S106', 'Scocial-Science'),
('Tech002', 'S102', 'English'),
('Tech004', 'S104', 'Science'),
('Tech003', 'S103', 'Maths'),
('Tech007', 'S107', 'Computer Science'),
('Tech006', 'S105', 'Hindi');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bus`
--
ALTER TABLE `bus`
  ADD PRIMARY KEY (`b_id`);

--
-- Indexes for table `cls`
--
ALTER TABLE `cls`
  ADD PRIMARY KEY (`c_id`);

--
-- Indexes for table `drileave`
--
ALTER TABLE `drileave`
  ADD PRIMARY KEY (`le_id`);

--
-- Indexes for table `fee`
--
ALTER TABLE `fee`
  ADD PRIMARY KEY (`f_id`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `function`
--
ALTER TABLE `function`
  ADD PRIMARY KEY (`f_id`);

--
-- Indexes for table `homework1`
--
ALTER TABLE `homework1`
  ADD PRIMARY KEY (`h_id`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pdf_files`
--
ALTER TABLE `pdf_files`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sports`
--
ALTER TABLE `sports`
  ADD PRIMARY KEY (`s_id`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`s_id`),
  ADD KEY `c_id` (`c_id`);

--
-- Indexes for table `studentleav`
--
ALTER TABLE `studentleav`
  ADD PRIMARY KEY (`le_id`);

--
-- Indexes for table `sub`
--
ALTER TABLE `sub`
  ADD PRIMARY KEY (`sub_id`);

--
-- Indexes for table `tbl_employee`
--
ALTER TABLE `tbl_employee`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `techleave`
--
ALTER TABLE `techleave`
  ADD PRIMARY KEY (`le_id`);

--
-- Indexes for table `tec_sub`
--
ALTER TABLE `tec_sub`
  ADD KEY `sub_id` (`sub_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `drileave`
--
ALTER TABLE `drileave`
  MODIFY `le_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=206;

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `homework1`
--
ALTER TABLE `homework1`
  MODIFY `h_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=447;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `pdf_files`
--
ALTER TABLE `pdf_files`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `studentleav`
--
ALTER TABLE `studentleav`
  MODIFY `le_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=215;

--
-- AUTO_INCREMENT for table `tbl_employee`
--
ALTER TABLE `tbl_employee`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=187;

--
-- AUTO_INCREMENT for table `techleave`
--
ALTER TABLE `techleave`
  MODIFY `le_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=207;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tec_sub`
--
ALTER TABLE `tec_sub`
  ADD CONSTRAINT `tec_sub_ibfk_1` FOREIGN KEY (`sub_id`) REFERENCES `sub` (`sub_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
